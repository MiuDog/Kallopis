# Kallopis 設計語意對照表（供其他專案與AI使用）

日期：2026-10-05；來源：Kallopis 0.8.0目前工作樹／預設風格1.0.0。**將本檔放進目標專案即可查表；本檔不依賴其他檔案。**本表記錄現有設計，不建立產品功能模板。

## 表格記號

| 記號 | 意義 |
|---|---|
| `p(名稱)` | 第一部分primitive名稱→實際值map。 |
| `s(ID)` | 第二部分semantic用途或完整配方。 |
| 繼承配方 | 先複製「繼承」欄指定配方，再覆寫本列參數；未列參數保留。 |
| 繼承父層 | 使用父容器／文字環境的值；不是全域預設。 |
| 繼承目前元件 | 保留目前variant和size，僅套用本列狀態。 |
| none | 明確不畫／不套用，不能改成繼承。 |
| 不適用 | 此用途不需要該參數。 |
| 產品決定／內容決定／父布局分配 | 未規定固定值，使用目標產品或布局，不由AI猜成公共token。 |
| alpha(color,opacity) | 保留RGB，替換alpha；不是乘上原本alpha。 |
| opaque(color) | 保留RGB，alpha設為1。 |
| over(front,back) | 使用alpha compositing疊色，對應Color.alphaBlend。 |
| add/sub/mul/div/max | 數值運算，保留長度與倍率的單位。 |
| byBrightness(light,dark) | surface相對亮度<0.5時取dark，否則light。 |
| primaryForeground(background) | 8-bit sRGB luma=0.299R+0.587G+0.114B；<160取theme.colors.onDarkBackground，否則onLightBackground。 |
| backgroundForeground(background) | 透明時繼承父層；非透明背景相對亮度<0.15取onDarkBackground／mutedOnDarkBackground，否則onLightBackground／mutedOnLightBackground；faint取faintOnBackground。 |

預設light/rest；button未指定size時為sm，compact=true時為xs；field預設md。button-base以md列出共用可覆寫值，解析元件時必須再套用正確size。色碼統一**#AARRGGBB**（alpha在前）；CSS需轉為#RRGGBBAA。不透明色可使用#RRGGBB。length為logical px／CSS px，duration為ms，ratio/opacity無單位，weight為字重整數，curve為cubic-bezier四點。父容器若有backgroundForeground覆寫，子樹的theme.colors.text/textMuted需使用覆寫後的值；不得一律從根主題拿文字色。

# 第一部分：Primitive token表格（名稱→實際值）

Primitive只定義值，不決定使用位置。269個primitive名稱；原有KlpScale／KlpPalette名稱全部保留；補充length-*等名稱只是替原實作數值建立文件原料ID，不是新增設計。字型保留Flutter package ownership；其他技術棧註冊對應Noto Sans TC／IBM Plex Mono，再移除packages/kallopis/前綴。fallback清單在後面的semantic表以primitive陣列表示。


## 顏色

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `parchment50` | `#FFF8F6F1` | 現有公開primitive |
| `parchment75` | `#FFF0EDE6` | 現有公開primitive |
| `parchment100` | `#FFEFEDE7` | 現有公開primitive |
| `parchment150` | `#FFE7E4DD` | 現有公開primitive |
| `parchment200` | `#FFE1DDD2` | 現有公開primitive |
| `parchment250` | `#FFD3CFC4` | 現有公開primitive |
| `parchment350` | `#FFBAB5AA` | 現有公開primitive |
| `parchment550` | `#FF6A655B` | 現有公開primitive |
| `parchment700` | `#FF514B40` | 現有公開primitive |
| `parchment750` | `#FF484339` | 現有公開primitive |
| `parchment800` | `#FF35322D` | 現有公開primitive |
| `parchment825` | `#FF33322C` | 現有公開primitive |
| `parchment900` | `#FF292724` | 現有公開primitive |
| `parchment925` | `#FF21201B` | 現有公開primitive |
| `parchment950` | `#FF201F1C` | 現有公開primitive |
| `ink1000` | `#FF000000` | 現有公開primitive |
| `transparent` | `#00000000` | 現有公開primitive |
| `ink50` | `#FFFFFFFF` | 現有公開primitive |
| `ink100` | `#FFF2F0EB` | 現有公開primitive |
| `ink150` | `#FFEAE7E1` | 現有公開primitive |
| `ink200` | `#FFE6E3DC` | 現有公開primitive |
| `ink250` | `#FFBCB8B0` | 現有公開primitive |
| `ink300` | `#FFADA89E` | 現有公開primitive |
| `ink350` | `#FF9E998F` | 現有公開primitive |
| `ink400` | `#FF8E8982` | 現有公開primitive |
| `ink450` | `#FF7F7A75` | 現有公開primitive |
| `ink500` | `#FF6F6C67` | 現有公開primitive |
| `ink550` | `#FF6B6459` | 現有公開primitive |
| `ink600` | `#FF4F5151` | 現有公開primitive |
| `ink650` | `#FF414344` | 現有公開primitive |
| `ink700` | `#FF343637` | 現有公開primitive |
| `ink750` | `#FF303030` | 現有公開primitive |
| `ink800` | `#FF292929` | 現有公開primitive |
| `ink850` | `#FF232323` | 現有公開primitive |
| `ink900` | `#FF1D1D1D` | 現有公開primitive |
| `ink950` | `#FF101010` | 現有公開primitive |
| `warmNeutral25` | `#FFF5F2EC` | 現有公開primitive |
| `warmNeutral50` | `#FFE4E1DA` | 現有公開primitive |
| `warmNeutral100` | `#FFD6D0C6` | 現有公開primitive |
| `warmNeutral200` | `#FFC8C0B4` | 現有公開primitive |
| `warmNeutral300` | `#FFB8B2A4` | 現有公開primitive |
| `warmNeutral400` | `#FF918A7B` | 現有公開primitive |
| `warmNeutral450` | `#FF8C8477` | 現有公開primitive |
| `warmNeutral500` | `#FF7A7566` | 現有公開primitive |
| `warmNeutral600` | `#FF6A6256` | 現有公開primitive |
| `warmNeutral700` | `#FF585249` | 現有公開primitive |
| `warmNeutral750` | `#FF45413A` | 現有公開primitive |
| `warmNeutral800` | `#FF433F3A` | 現有公開primitive |
| `warmNeutral900` | `#FF34302B` | 現有公開primitive |
| `sand50` | `#FFF8F1E2` | 現有公開primitive |
| `sand300` | `#FFF0D79A` | 現有公開primitive |
| `sand500` | `#FFE0BE73` | 現有公開primitive |
| `sand800` | `#FF453D2B` | 現有公開primitive |
| `sand900` | `#FF302B20` | 現有公開primitive |
| `gold50` | `#FFF6EBD7` | 現有公開primitive |
| `gold300` | `#FFE8BD70` | 現有公開primitive |
| `gold500` | `#FFD3A152` | 現有公開primitive |
| `gold800` | `#FF443725` | 現有公開primitive |
| `gold900` | `#FF30271B` | 現有公開primitive |
| `ochre50` | `#FFF3E4CF` | 現有公開primitive |
| `ochre300` | `#FFDFA04E` | 現有公開primitive |
| `ochre500` | `#FFC6823D` | 現有公開primitive |
| `ochre800` | `#FF413222` | 現有公開primitive |
| `ochre900` | `#FF2E241A` | 現有公開primitive |
| `terracotta50` | `#FFEEDDD0` | 現有公開primitive |
| `terracotta300` | `#FFC88745` | 現有公開primitive |
| `terracotta500` | `#FFA96836` | 現有公開primitive |
| `terracotta800` | `#FF3D2D22` | 現有公開primitive |
| `terracotta900` | `#FF2C211B` | 現有公開primitive |
| `clay50` | `#FFE9D8D1` | 現有公開primitive |
| `clay300` | `#FFA86D43` | 現有公開primitive |
| `clay500` | `#FF895137` | 現有公開primitive |
| `clay800` | `#FF382A23` | 現有公開primitive |
| `clay900` | `#FF291F1C` | 現有公開primitive |
| `umber50` | `#FFE4D5D1` | 現有公開primitive |
| `umber300` | `#FF89573E` | 現有公開primitive |
| `umber500` | `#FF683E33` | 現有公開primitive |
| `umber800` | `#FF332724` | 現有公開primitive |
| `umber900` | `#FF261D1C` | 現有公開primitive |
| `green100` | `#FFDFF0E5` | 現有公開primitive |
| `green400` | `#FF67AE86` | 現有公開primitive |
| `green500` | `#FF51B77B` | 現有公開primitive |
| `green600` | `#FF2D8057` | 現有公開primitive |
| `green800` | `#FF243B2D` | 現有公開primitive |
| `green900` | `#FF1D3025` | 現有公開primitive |
| `red100` | `#FFFAE3E2` | 現有公開primitive |
| `red300` | `#FFFA6C73` | 現有公開primitive |
| `red400` | `#FFD27B74` | 現有公開primitive |
| `red600` | `#FFA7443F` | 現有公開primitive |
| `red800` | `#FF472925` | 現有公開primitive |
| `red900` | `#FF3B2320` | 現有公開primitive |
| `amber500` | `#FFF6B52E` | 現有公開primitive |
| `blue500` | `#FF5499DF` | 現有公開primitive |
| `scrim` | `#99010202` | 現有公開primitive |
| `line` | `#00000000` | 現有公開primitive |
| `transparentSurface` | `#9426292D` | 現有公開primitive |
| `transparentSurfaceInset` | `#A8404449` | 現有公開primitive |
| `pureWhite` | `#FFFFFFFF` | 現有公開primitive |
| `pureBlack` | `#FF000000` | 現有公開primitive |
| `accent-ink-light` | `#FF1D1D1D` | 現有accent配對原料 |
| `accent-ink-dark` | `#FFFFFFFF` | 現有accent配對原料 |
| `accent-terracotta-light` | `#FF92563C` | 現有accent配對原料 |
| `accent-terracotta-dark` | `#FFCB8E72` | 現有accent配對原料 |
| `accent-ochre-light` | `#FF7D612F` | 現有accent配對原料 |
| `accent-ochre-dark` | `#FFB99860` | 現有accent配對原料 |
| `accent-olive-light` | `#FF5E6A39` | 現有accent配對原料 |
| `accent-olive-dark` | `#FF94A366` | 現有accent配對原料 |
| `accent-slate-light` | `#FF4E678A` | 現有accent配對原料 |
| `accent-slate-dark` | `#FF879EBD` | 現有accent配對原料 |
| `accent-crimson-light` | `#FF9F4B59` | 現有accent配對原料 |
| `accent-crimson-dark` | `#FFCE8A95` | 現有accent配對原料 |
| `color-b8292724` | `#B8292724` | 原實作值的文件名稱；未新增設計 |
| `color-b835322d` | `#B835322D` | 原實作值的文件名稱；未新增設計 |

## 間距、尺寸、圓角、線寬與字距

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `space0` | `0` | 現有公開primitive |
| `space50` | `2` | 現有公開primitive |
| `space100` | `4` | 現有公開primitive |
| `space200` | `8` | 現有公開primitive |
| `space250` | `10` | 現有公開primitive |
| `space300` | `12` | 現有公開primitive |
| `space400` | `16` | 現有公開primitive |
| `space600` | `24` | 現有公開primitive |
| `space800` | `32` | 現有公開primitive |
| `space1000` | `40` | 現有公開primitive |
| `space1200` | `48` | 現有公開primitive |
| `space1600` | `64` | 現有公開primitive |
| `space2400` | `96` | 現有公開primitive |
| `radius0` | `0` | 現有公開primitive |
| `radius50` | `2` | 現有公開primitive |
| `radius100` | `4` | 現有公開primitive |
| `radius150` | `6` | 現有公開primitive |
| `radius200` | `8` | 現有公開primitive |
| `radius250` | `10` | 現有公開primitive |
| `radius300` | `12` | 現有公開primitive |
| `radius400` | `16` | 現有公開primitive |
| `radiusFull` | `9999` | 現有公開primitive |
| `stroke0` | `0` | 現有公開primitive |
| `stroke100` | `1` | 現有公開primitive |
| `stroke200` | `2` | 現有公開primitive |
| `font100` | `10` | 現有公開primitive |
| `font200` | `12` | 現有公開primitive |
| `font300` | `14` | 現有公開primitive |
| `font400` | `16` | 現有公開primitive |
| `font500` | `18` | 現有公開primitive |
| `font600` | `22` | 現有公開primitive |
| `font700` | `28` | 現有公開primitive |
| `font800` | `36` | 現有公開primitive |
| `font900` | `48` | 現有公開primitive |
| `font1000` | `64` | 現有公開primitive |
| `tracking0` | `0` | 現有公開primitive |
| `trackingTight` | `-0.5` | 現有公開primitive |
| `trackingWide` | `1.2` | 現有公開primitive |
| `trackingWider` | `1.32` | 現有公開primitive |
| `length-30` | `30` | 原實作值的文件名稱；未新增設計 |
| `length-56` | `56` | 原實作值的文件名稱；未新增設計 |
| `length-20` | `20` | 原實作值的文件名稱；未新增設計 |
| `length-60` | `60` | 原實作值的文件名稱；未新增設計 |
| `length-74` | `74` | 原實作值的文件名稱；未新增設計 |
| `length-170` | `170` | 原實作值的文件名稱；未新增設計 |
| `length-11` | `11` | 原實作值的文件名稱；未新增設計 |
| `length-3` | `3` | 原實作值的文件名稱；未新增設計 |
| `length-5` | `5` | 原實作值的文件名稱；未新增設計 |
| `length-7` | `7` | 原實作值的文件名稱；未新增設計 |
| `length-3_5` | `3.5` | 原實作值的文件名稱；未新增設計 |
| `length-41_4` | `41.4` | 原實作值的文件名稱；未新增設計 |
| `length-168` | `168` | 原實作值的文件名稱；未新增設計 |
| `length-26` | `26` | 原實作值的文件名稱；未新增設計 |
| `length-520` | `520` | 原實作值的文件名稱；未新增設計 |
| `length-320` | `320` | 原實作值的文件名稱；未新增設計 |
| `length-120` | `120` | 原實作值的文件名稱；未新增設計 |
| `length-9` | `9` | 原實作值的文件名稱；未新增設計 |
| `length-220` | `220` | 原實作值的文件名稱；未新增設計 |
| `length-192` | `192` | 原實作值的文件名稱；未新增設計 |
| `length-128` | `128` | 原實作值的文件名稱；未新增設計 |
| `length-112` | `112` | 原實作值的文件名稱；未新增設計 |
| `length-10_5` | `10.5` | 原實作值的文件名稱；未新增設計 |
| `length-336` | `336` | 原實作值的文件名稱；未新增設計 |
| `length-300` | `300` | 原實作值的文件名稱；未新增設計 |
| `length-350` | `350` | 原實作值的文件名稱；未新增設計 |
| `length-400` | `400` | 原實作值的文件名稱；未新增設計 |
| `length-800` | `800` | 原實作值的文件名稱；未新增設計 |
| `length-960` | `960` | 原實作值的文件名稱；未新增設計 |
| `length-1120` | `1120` | 原實作值的文件名稱；未新增設計 |
| `length-200` | `200` | 原實作值的文件名稱；未新增設計 |
| `length-360` | `360` | 原實作值的文件名稱；未新增設計 |
| `length-480` | `480` | 原實作值的文件名稱；未新增設計 |
| `length-1380` | `1380` | 原實作值的文件名稱；未新增設計 |
| `length-880` | `880` | 原實作值的文件名稱；未新增設計 |
| `length-260` | `260` | 原實作值的文件名稱；未新增設計 |
| `length-820` | `820` | 原實作值的文件名稱；未新增設計 |
| `length-minus-1` | `-1` | 原實作值的文件名稱；未新增設計 |

## 行高與倍率

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `leading100` | `1.125` | 現有公開primitive |
| `leading116` | `1.166` | 現有公開primitive |
| `leading120` | `1.2` | 現有公開primitive |
| `leading122` | `1.222` | 現有公開primitive |
| `leading127` | `1.272` | 現有公開primitive |
| `leading128` | `1.285` | 現有公開primitive |
| `leading133` | `1.333` | 現有公開primitive |
| `leading142` | `1.428` | 現有公開primitive |
| `leading150` | `1.5` | 現有公開primitive |
| `leading155` | `1.555` | 現有公開primitive |
| `leading150Legacy` | `1.2` | 現有公開primitive |
| `leading200` | `1.25` | 現有公開primitive |
| `leading300` | `1.3` | 現有公開primitive |
| `leading350` | `1.35` | 現有公開primitive |
| `leading400` | `1.4` | 現有公開primitive |
| `leading450` | `1.45` | 現有公開primitive |
| `leading500` | `1.5` | 現有公開primitive |
| `leading550` | `1.55` | 現有公開primitive |
| `leading650` | `1.65` | 現有公開primitive |
| `ratio-0_4` | `0.4` | 原實作值的文件名稱；未新增設計 |
| `ratio-0_35` | `0.35` | 原實作值的文件名稱；未新增設計 |
| `ratio-0_32` | `0.32` | 原實作值的文件名稱；未新增設計 |
| `ratio-0_22` | `0.22` | 原實作值的文件名稱；未新增設計 |
| `ratio-0_06` | `0.06` | 原實作值的文件名稱；未新增設計 |
| `ratio-8` | `8` | 原實作值的文件名稱；未新增設計 |
| `ratio-2` | `2` | 原實作值的文件名稱；未新增設計 |
| `ratio-3` | `3` | 原實作值的文件名稱；未新增設計 |
| `ratio-6` | `6` | 原實作值的文件名稱；未新增設計 |

## 字重

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `weight400` | `400` | 現有公開primitive |
| `weight500` | `500` | 現有公開primitive |
| `weight600` | `600` | 現有公開primitive |
| `weight700` | `700` | 現有公開primitive |
| `weight800` | `800` | 現有公開primitive |

## 時間

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `duration0` | `0` | 現有公開primitive |
| `duration100` | `120` | 現有公開primitive |
| `duration150` | `140` | 現有公開primitive |
| `duration400` | `450` | 現有公開primitive |
| `duration500` | `500` | 現有公開primitive |
| `duration-4000` | `4000` | 原實作值的文件名稱；未新增設計 |
| `duration-1000` | `1000` | 原實作值的文件名稱；未新增設計 |

## 緩動

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `easeStandard` | `[0.215, 0.61, 0.355, 1.0]` | 現有公開primitive |
| `easeEmphasized` | `[0.645, 0.045, 0.355, 1.0]` | 現有公開primitive |

## 透明度

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `opacity100` | `0.1` | 現有公開primitive |
| `opacity120` | `0.12` | 現有公開primitive |
| `opacity140` | `0.14` | 現有公開primitive |
| `opacity160` | `0.16` | 現有公開primitive |
| `opacity180` | `0.18` | 現有公開primitive |
| `opacity220` | `0.22` | 現有公開primitive |
| `opacity280` | `0.28` | 現有公開primitive |
| `opacity320` | `0.32` | 現有公開primitive |
| `opacity350` | `0.35` | 現有公開primitive |
| `opacity440` | `0.44` | 現有公開primitive |
| `opacity480` | `0.48` | 現有公開primitive |
| `opacity550` | `0.55` | 現有公開primitive |
| `opacity620` | `0.62` | 現有公開primitive |
| `opacity720` | `0.72` | 現有公開primitive |
| `opacity780` | `0.78` | 現有公開primitive |
| `opacity820` | `0.82` | 現有公開primitive |
| `opacity-0_13333333333333333` | `0.13333333333333333` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_6` | `0.6` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_88` | `0.88` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_47843137254901963` | `0.47843137254901963` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_1803921568627451` | `0.1803921568627451` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_07058823529411765` | `0.07058823529411765` | 原實作值的文件名稱；未新增設計 |
| `opacity-0_8509803921568627` | `0.8509803921568627` | 原實作值的文件名稱；未新增設計 |

## 字型／fallback名稱

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `family-packages-kallopis-noto-sans-tc` | `packages/kallopis/Noto Sans TC` | 原實作值的文件名稱；未新增設計 |
| `family-noto-sans-tc` | `Noto Sans TC` | 原實作值的文件名稱；未新增設計 |
| `family-microsoft-jhenghei-ui` | `Microsoft JhengHei UI` | 原實作值的文件名稱；未新增設計 |
| `family-microsoft-jhenghei` | `Microsoft JhengHei` | 原實作值的文件名稱；未新增設計 |
| `family-pingfang-tc` | `PingFang TC` | 原實作值的文件名稱；未新增設計 |
| `family-sans-serif` | `sans-serif` | 原實作值的文件名稱；未新增設計 |
| `family-packages-kallopis-ibm-plex-mono` | `packages/kallopis/IBM Plex Mono` | 原實作值的文件名稱；未新增設計 |
| `family-ibm-plex-mono` | `IBM Plex Mono` | 原實作值的文件名稱；未新增設計 |
| `family-consolas` | `Consolas` | 原實作值的文件名稱；未新增設計 |
| `family-courier-new` | `Courier New` | 原實作值的文件名稱；未新增設計 |
| `family-monospace` | `monospace` | 原實作值的文件名稱；未新增設計 |

## 模式

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `string-shadow` | `shadow` | 原實作值的文件名稱；未新增設計 |

## 數量

| Primitive名稱 | 實際值 | 來源 |
|---|---|---|
| `count-4` | `4` | 原實作值的文件名稱；未新增設計 |
| `count-8` | `8` | 原實作值的文件名稱；未新增設計 |

# 第二部分：Semantic token表格（自然語言→設計組合）

## AI解析規則

| 步驟 | 執行方式 |
|---|---|
| 1 | 從對話識別元件用途、主題、size、tone、state，再查中文／英文別名取得canonical ID。單獨的primary不能直接當作任意藍色。 |
| 2 | 展開繼承；按鈕／欄位以base→variant→size→state合併。primary在尺寸套用後再次選captionStrong（xs/sm）、bodyStrong（md）、lead（lg/xl）。 |
| 3 | 將s(theme.*)依主題查成p(...)，再查實際值；公式在最後計算。 |
| 4 | button狀態：disabled>selected>hover/focus>rest；field：disabled>error>focus>hover>rest。outlined/multiline分別覆寫自己的參數。圖示按鈕disabled仍保留selected底色。 |
| 5 | 使用者明確覆寫優先，其餘遵照本表；需要的語意缺漏時不杜撰已定型公共配方。產品專用尺寸與流程由產品擁有。 |
| 6 | 實作說明列出使用的semantic ID與覆寫欄位。Flutter用公開theme／元件；其他技術棧集中維護同一份semantic map。 |

## 全域semantic值（theme.*）

完整350個公開主題欄位，陣列算一個欄位。components預設null，表中列出其**繼承解析**來源；null不是0。元件配方是後方的表格，不把每個theme欄位當作完整元件。


### colors

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.colors.app`<br>app background／應用背景色 | `p(parchment150)` | `p(parchment950)` | `p(ink950)` | `p(transparent)` |
| `theme.colors.surface`<br>base surface／輔助表面色 | `p(parchment100)` | `p(parchment900)` | `p(ink850)` | `p(color-b8292724)` |
| `theme.colors.surfaceInset`<br>inset surface／內嵌表面色 | `p(parchment100)` | `p(parchment900)` | `p(ink850)` | `p(parchment900)` |
| `theme.colors.surfaceMuted`<br>muted surface／弱化表面色 | `p(parchment200)` | `p(parchment750)` | `p(ink850)` | `p(parchment750)` |
| `theme.colors.component`<br>control surface／控制表面色 | `p(parchment50)` | `p(parchment800)` | `p(ink900)` | `p(parchment800)` |
| `theme.colors.stageSurface`<br>stage background／主內容表面色 | `p(parchment50)` | `p(parchment800)` | `p(ink900)` | `p(color-b835322d)` |
| `theme.colors.overlay`<br>overlay background／浮層色 | `p(parchment50)` | `p(parchment800)` | `p(ink850)` | `p(parchment800)` |
| `theme.colors.surfaceRaised`<br>raised surface／較亮表面 | `p(parchment50)` | `p(parchment800)` | `p(ink850)` | `p(parchment800)` |
| `theme.colors.modalScrim`<br>遮罩色 | `p(scrim)` | `p(scrim)` | `p(scrim)` | `p(scrim)` |
| `theme.colors.guide`<br>colors / guide | `p(parchment250)` | `p(parchment700)` | `p(ink450)` | `p(parchment700)` |
| `theme.colors.divider`<br>分隔線色 | `p(parchment250)` | `p(parchment700)` | `p(ink800)` | `p(parchment700)` |
| `theme.colors.pagePattern`<br>colors / page Pattern | `p(parchment250)` | `p(parchment700)` | `p(ink650)` | `p(parchment700)` |
| `theme.colors.text`<br>primary text／主文字 | `p(parchment925)` | `p(parchment75)` | `p(ink100)` | `p(parchment75)` |
| `theme.colors.textMuted`<br>muted text／次要文字 | `p(parchment550)` | `p(parchment350)` | `p(ink350)` | `p(parchment350)` |
| `theme.colors.textFaint`<br>faint text／弱化文字 | `p(parchment550)` | `p(parchment350)` | `p(ink400)` | `p(parchment350)` |
| `theme.colors.border`<br>邊框色 | `p(parchment250)` | `p(parchment700)` | `p(transparent)` | `p(parchment700)` |
| `theme.colors.borderStrong`<br>colors / border Strong | `p(parchment250)` | `p(parchment700)` | `p(transparent)` | `p(parchment700)` |
| `theme.colors.brand`<br>brand／品牌色／主動作底色 | `p(ink900)` | `p(ink50)` | `p(ink100)` | `p(ink50)` |
| `theme.colors.accent`<br>colors / accent | `p(ink900)` | `p(ink50)` | `p(ink100)` | `p(ink50)` |
| `theme.colors.accentSoft`<br>colors / accent Soft | `p(ink200)` | `p(ink750)` | `p(ink850)` | `p(ink750)` |
| `theme.colors.interaction`<br>interaction／操作色 | `p(ink900)` | `p(ink50)` | `p(ink100)` | `p(ink50)` |
| `theme.colors.interactionSoft`<br>selection background／柔和操作色 | `p(ink200)` | `p(ink750)` | `p(ink850)` | `p(ink750)` |
| `theme.colors.success`<br>colors / success | `p(green500)` | `p(green500)` | `p(green500)` | `p(green500)` |
| `theme.colors.warning`<br>colors / warning | `p(amber500)` | `p(amber500)` | `p(amber500)` | `p(amber500)` |
| `theme.colors.danger`<br>colors / danger | `p(red300)` | `p(red300)` | `p(red300)` | `p(red300)` |
| `theme.colors.info`<br>colors / info | `p(blue500)` | `p(blue500)` | `p(blue500)` | `p(blue500)` |
| `theme.colors.onStatus`<br>colors / on Status | `p(ink50)` | `p(ink50)` | `p(ink50)` | `p(ink50)` |
| `theme.colors.onLightBackground`<br>colors / on Light Background | `p(parchment925)` | `p(parchment925)` | `p(ink900)` | `p(parchment925)` |
| `theme.colors.onDarkBackground`<br>colors / on Dark Background | `p(parchment75)` | `p(parchment75)` | `p(ink50)` | `p(parchment75)` |
| `theme.colors.mutedOnLightBackground`<br>colors / muted On Light Background | `p(parchment550)` | `p(parchment550)` | `p(ink550)` | `p(parchment550)` |
| `theme.colors.mutedOnDarkBackground`<br>colors / muted On Dark Background | `p(parchment350)` | `p(parchment350)` | `p(ink300)` | `p(parchment350)` |
| `theme.colors.faintOnBackground`<br>colors / faint On Background | `p(parchment550)` | `p(parchment350)` | `p(ink400)` | `p(parchment350)` |
| `theme.colors.transparent`<br>透明 | `p(transparent)` | `p(transparent)` | `p(transparent)` | `p(transparent)` |

### typography

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.typography.sansFamily`<br>typography / sans Family | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` |
| `theme.typography.sansFallback`<br>typography / sans Fallback | `[p(family-noto-sans-tc), p(family-microsoft-jhenghei-ui), p(family-microsoft-jhenghei), p(family-pingfang-tc), p(family-sans-serif)]` | `[p(family-noto-sans-tc), p(family-microsoft-jhenghei-ui), p(family-microsoft-jhenghei), p(family-pingfang-tc), p(family-sans-serif)]` | `[p(family-noto-sans-tc), p(family-microsoft-jhenghei-ui), p(family-microsoft-jhenghei), p(family-pingfang-tc), p(family-sans-serif)]` | `[p(family-noto-sans-tc), p(family-microsoft-jhenghei-ui), p(family-microsoft-jhenghei), p(family-pingfang-tc), p(family-sans-serif)]` |
| `theme.typography.monoFamily`<br>typography / mono Family | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` |
| `theme.typography.monoFallback`<br>typography / mono Fallback | `[p(family-packages-kallopis-noto-sans-tc), p(family-ibm-plex-mono), p(family-consolas), p(family-courier-new), p(family-monospace)]` | `[p(family-packages-kallopis-noto-sans-tc), p(family-ibm-plex-mono), p(family-consolas), p(family-courier-new), p(family-monospace)]` | `[p(family-packages-kallopis-noto-sans-tc), p(family-ibm-plex-mono), p(family-consolas), p(family-courier-new), p(family-monospace)]` | `[p(family-packages-kallopis-noto-sans-tc), p(family-ibm-plex-mono), p(family-consolas), p(family-courier-new), p(family-monospace)]` |
| `theme.typography.uiFamily`<br>typography / ui Family | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` |
| `theme.typography.bodyFamily`<br>typography / body Family | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` | `p(family-packages-kallopis-noto-sans-tc)` |
| `theme.typography.codeFamily`<br>typography / code Family | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` | `p(family-packages-kallopis-ibm-plex-mono)` |
| `theme.typography.micro`<br>typography / micro | `p(space250)` | `p(space250)` | `p(space250)` | `p(space250)` |
| `theme.typography.caption`<br>typography / caption | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.typography.sub`<br>typography / sub | `p(font300)` | `p(font300)` | `p(font300)` | `p(font300)` |
| `theme.typography.body`<br>typography / body | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.typography.lead`<br>typography / lead | `p(font500)` | `p(font500)` | `p(font500)` | `p(font500)` |
| `theme.typography.h4`<br>typography / h4 | `p(font600)` | `p(font600)` | `p(font600)` | `p(font600)` |
| `theme.typography.h3`<br>typography / h3 | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.typography.h2`<br>typography / h2 | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.typography.h1`<br>typography / h1 | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.typography.display`<br>typography / display | `p(space1600)` | `p(space1600)` | `p(space1600)` | `p(space1600)` |
| `theme.typography.label`<br>typography / label | `p(font300)` | `p(font300)` | `p(font300)` | `p(font300)` |
| `theme.typography.section`<br>typography / section | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.typography.headingSmall`<br>typography / heading Small | `p(font600)` | `p(font600)` | `p(font600)` | `p(font600)` |
| `theme.typography.heading`<br>typography / heading | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.typography.title`<br>typography / title | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.typography.microLeading`<br>typography / micro Leading | `p(leading120)` | `p(leading120)` | `p(leading120)` | `p(leading120)` |
| `theme.typography.captionLeading`<br>typography / caption Leading | `p(leading133)` | `p(leading133)` | `p(leading133)` | `p(leading133)` |
| `theme.typography.subLeading`<br>typography / sub Leading | `p(leading142)` | `p(leading142)` | `p(leading142)` | `p(leading142)` |
| `theme.typography.bodyLeading`<br>typography / body Leading | `p(leading150)` | `p(leading150)` | `p(leading150)` | `p(leading150)` |
| `theme.typography.leadLeading`<br>typography / lead Leading | `p(leading155)` | `p(leading155)` | `p(leading155)` | `p(leading155)` |
| `theme.typography.h4Leading`<br>typography / h4Leading | `p(leading127)` | `p(leading127)` | `p(leading127)` | `p(leading127)` |
| `theme.typography.h3Leading`<br>typography / h3Leading | `p(leading128)` | `p(leading128)` | `p(leading128)` | `p(leading128)` |
| `theme.typography.h2Leading`<br>typography / h2Leading | `p(leading122)` | `p(leading122)` | `p(leading122)` | `p(leading122)` |
| `theme.typography.h1Leading`<br>typography / h1Leading | `p(leading116)` | `p(leading116)` | `p(leading116)` | `p(leading116)` |
| `theme.typography.displayLeading`<br>typography / display Leading | `p(leading100)` | `p(leading100)` | `p(leading100)` | `p(leading100)` |
| `theme.typography.headingLeading`<br>typography / heading Leading | `p(leading122)` | `p(leading122)` | `p(leading122)` | `p(leading122)` |
| `theme.typography.codeLeading`<br>typography / code Leading | `p(leading142)` | `p(leading142)` | `p(leading142)` | `p(leading142)` |
| `theme.typography.readingLeading`<br>typography / reading Leading | `p(leading155)` | `p(leading155)` | `p(leading155)` | `p(leading155)` |
| `theme.typography.labelLeading`<br>typography / label Leading | `p(leading133)` | `p(leading133)` | `p(leading133)` | `p(leading133)` |
| `theme.typography.labelTracking`<br>typography / label Tracking | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |
| `theme.typography.displayTracking`<br>typography / display Tracking | `p(trackingTight)` | `p(trackingTight)` | `p(trackingTight)` | `p(trackingTight)` |
| `theme.typography.regular`<br>typography / regular | `p(weight400)` | `p(weight400)` | `p(weight400)` | `p(weight400)` |
| `theme.typography.medium`<br>typography / medium | `p(weight400)` | `p(weight400)` | `p(weight400)` | `p(weight400)` |
| `theme.typography.semiBold`<br>typography / semi Bold | `p(weight600)` | `p(weight600)` | `p(weight600)` | `p(weight600)` |
| `theme.typography.bold`<br>typography / bold | `p(weight700)` | `p(weight700)` | `p(weight700)` | `p(weight700)` |
| `theme.typography.extraBold`<br>typography / extra Bold | `p(weight700)` | `p(weight700)` | `p(weight700)` | `p(weight700)` |
| `theme.typography.strong`<br>typography / strong | `p(weight600)` | `p(weight600)` | `p(weight600)` | `p(weight600)` |

### spacing

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.spacing.space0_5`<br>spacing / space0_5 | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.spacing.space1`<br>spacing / space1 | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.spacing.space2`<br>spacing / space2 | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.space3`<br>spacing / space3 | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.spacing.space4`<br>spacing / space4 | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.space6`<br>spacing / space6 | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.space8`<br>spacing / space8 | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.space12`<br>spacing / space12 | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.spacing.space16`<br>spacing / space16 | `p(space1600)` | `p(space1600)` | `p(space1600)` | `p(space1600)` |
| `theme.spacing.space24`<br>spacing / space24 | `p(space2400)` | `p(space2400)` | `p(space2400)` | `p(space2400)` |
| `theme.spacing.hairline`<br>spacing / hairline | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.spacing.tight`<br>spacing / tight | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.spacing.contentInlineGap`<br>spacing / content Inline Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.contentStackGap`<br>spacing / content Stack Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.contentInset`<br>spacing / content Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.controlContentGap`<br>spacing / control Content Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.controlInset`<br>spacing / control Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.actionGap`<br>spacing / action Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.chromeGap`<br>spacing / chrome Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.chromePanelInset`<br>spacing / chrome Panel Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.chromeToolbarGap`<br>spacing / chrome Toolbar Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.navigationItemInset`<br>spacing / navigation Item Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.navigationRailInset`<br>spacing / navigation Rail Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.navigationRailItemGap`<br>spacing / navigation Rail Item Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.overlayContentInset`<br>spacing / overlay Content Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.overlayHeadingGap`<br>spacing / overlay Heading Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.overlayItemGap`<br>spacing / overlay Item Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.navigationSectionGap`<br>spacing / navigation Section Gap | `p(radius150)` | `p(radius150)` | `p(radius150)` | `p(radius150)` |
| `theme.spacing.appFrameInset`<br>spacing / app Frame Inset | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.spacing.windowHeaderMargin`<br>spacing / window Header Margin | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.spacing.dockMargin`<br>spacing / dock Margin | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.spacing.base`<br>spacing / base | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.comfortable`<br>spacing / comfortable | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.loose`<br>spacing / loose | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.section`<br>spacing / section | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.sectionLarge`<br>spacing / section Large | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.spacing.page`<br>spacing / page | `p(space1600)` | `p(space1600)` | `p(space1600)` | `p(space1600)` |
| `theme.spacing.pageLarge`<br>spacing / page Large | `p(space2400)` | `p(space2400)` | `p(space2400)` | `p(space2400)` |
| `theme.spacing.controlPaddingXSmall`<br>spacing / control Padding XSmall | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.spacing.controlPaddingX`<br>spacing / control Padding X | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.controlPaddingXLarge`<br>spacing / control Padding XLarge | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.controlPaddingXXLarge`<br>spacing / control Padding XXLarge | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.controlPaddingY`<br>spacing / control Padding Y | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.containerPadding`<br>spacing / container Padding | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.itemGap`<br>spacing / item Gap | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.spacing.groupGap`<br>spacing / group Gap | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.controlHeightXSmall`<br>spacing / control Height XSmall | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.spacing.controlHeightSmall`<br>spacing / control Height Small | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.spacing.controlHeight`<br>spacing / control Height | `p(space1000)` | `p(space1000)` | `p(space1000)` | `p(space1000)` |
| `theme.spacing.controlHeightLarge`<br>spacing / control Height Large | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.spacing.controlHeightXLarge`<br>spacing / control Height XLarge | `p(length-56)` | `p(length-56)` | `p(length-56)` | `p(length-56)` |
| `theme.spacing.iconSmall`<br>spacing / icon Small | `p(font300)` | `p(font300)` | `p(font300)` | `p(font300)` |
| `theme.spacing.iconBase`<br>spacing / icon Base | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.spacing.iconGlyph`<br>spacing / icon Glyph | `p(font500)` | `p(font500)` | `p(font500)` | `p(font500)` |
| `theme.spacing.icon`<br>spacing / icon | `p(length-20)` | `p(length-20)` | `p(length-20)` | `p(length-20)` |
| `theme.spacing.iconMedium`<br>spacing / icon Medium | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.iconLarge`<br>spacing / icon Large | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.chromeHeader`<br>spacing / chrome Header | `p(length-60)` | `p(length-60)` | `p(length-60)` | `p(length-60)` |
| `theme.spacing.chromeStatusBar`<br>spacing / chrome Status Bar | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.spacing.chromeRail`<br>spacing / chrome Rail | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.spacing.chromeTab`<br>spacing / chrome Tab | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.iconButton`<br>spacing / icon Button | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.spacing.iconTiny`<br>spacing / icon Tiny | `p(space250)` | `p(space250)` | `p(space250)` | `p(space250)` |
| `theme.spacing.indicatorDot`<br>spacing / indicator Dot | `p(radius150)` | `p(radius150)` | `p(radius150)` | `p(radius150)` |
| `theme.spacing.indicatorDotLarge`<br>spacing / indicator Dot Large | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.spacing.noticeIconSlot`<br>spacing / notice Icon Slot | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.spacing.toastIconSlot`<br>spacing / toast Icon Slot | `p(font600)` | `p(font600)` | `p(font600)` | `p(font600)` |
| `theme.spacing.gutterNumber`<br>spacing / gutter Number | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.gutterMarker`<br>spacing / gutter Marker | `p(font300)` | `p(font300)` | `p(font300)` | `p(font300)` |
| `theme.spacing.micro`<br>spacing / micro | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` |
| `theme.spacing.calendarContentCell`<br>spacing / calendar Content Cell | `p(length-74)` | `p(length-74)` | `p(length-74)` | `p(length-74)` |
| `theme.spacing.gridTileWidth`<br>spacing / grid Tile Width | `p(length-170)` | `p(length-170)` | `p(length-170)` | `p(length-170)` |
| `theme.spacing.iconMicro`<br>spacing / icon Micro | `p(length-11)` | `p(length-11)` | `p(length-11)` | `p(length-11)` |
| `theme.spacing.avatarSmall`<br>spacing / avatar Small | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.spacing.progressTrack`<br>spacing / progress Track | `p(length-3)` | `p(length-3)` | `p(length-3)` | `p(length-3)` |
| `theme.spacing.skeletonLine`<br>spacing / skeleton Line | `p(space250)` | `p(space250)` | `p(space250)` | `p(space250)` |
| `theme.spacing.railItem`<br>spacing / rail Item | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |

### shape

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.shape.none`<br>shape / none | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |
| `theme.shape.sm`<br>shape / sm | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.shape.control`<br>shape / control | `p(radius150)` | `p(radius150)` | `p(radius150)` | `p(radius150)` |
| `theme.shape.controlInner`<br>shape / control Inner | `p(length-5)` | `p(length-5)` | `p(length-5)` | `p(length-5)` |
| `theme.shape.toggleTrack`<br>shape / toggle Track | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.shape.card`<br>shape / card | `p(length-7)` | `p(length-7)` | `p(length-7)` | `p(length-7)` |
| `theme.shape.panel`<br>shape / panel | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.shape.pill`<br>shape / pill | `p(radiusFull)` | `p(radiusFull)` | `p(radiusFull)` | `p(radiusFull)` |
| `theme.shape.hairline`<br>shape / hairline | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` |
| `theme.shape.stroke`<br>shape / stroke | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.shape.dashedLength`<br>shape / dashed Length | `p(length-3)` | `p(length-3)` | `p(length-3)` | `p(length-3)` |
| `theme.shape.dashedGap`<br>shape / dashed Gap | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.shape.dashedOpacity`<br>shape / dashed Opacity | `p(opacity780)` | `p(opacity780)` | `p(opacity780)` | `p(opacity780)` |

### motion

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.motion.themeTransition`<br>motion / theme Transition | `p(duration0)` | `p(duration0)` | `p(duration0)` | `p(duration0)` |
| `theme.motion.styleTransition`<br>motion / style Transition | `p(duration0)` | `p(duration0)` | `p(duration0)` | `p(duration0)` |
| `theme.motion.stateTransition`<br>motion / state Transition | `p(duration150)` | `p(duration150)` | `p(duration150)` | `p(duration150)` |
| `theme.motion.overlayEnter`<br>motion / overlay Enter | `p(duration150)` | `p(duration150)` | `p(duration150)` | `p(duration150)` |
| `theme.motion.overlayExit`<br>motion / overlay Exit | `p(duration100)` | `p(duration100)` | `p(duration100)` | `p(duration100)` |
| `theme.motion.toastDwell`<br>motion / toast Dwell | `p(duration500)` | `p(duration500)` | `p(duration500)` | `p(duration500)` |
| `theme.motion.tooltipDelay`<br>motion / tooltip Delay | `p(duration400)` | `p(duration400)` | `p(duration400)` | `p(duration400)` |
| `theme.motion.tooltipDwell`<br>motion / tooltip Dwell | `p(duration-4000)` | `p(duration-4000)` | `p(duration-4000)` | `p(duration-4000)` |
| `theme.motion.spinnerCycle`<br>motion / spinner Cycle | `p(duration-1000)` | `p(duration-1000)` | `p(duration-1000)` | `p(duration-1000)` |
| `theme.motion.longPressThreshold`<br>motion / long Press Threshold | `p(duration500)` | `p(duration500)` | `p(duration500)` | `p(duration500)` |
| `theme.motion.standard`<br>motion / standard | `p(easeStandard)` | `p(easeStandard)` | `p(easeStandard)` | `p(easeStandard)` |
| `theme.motion.emphasized`<br>motion / emphasized | `p(easeEmphasized)` | `p(easeEmphasized)` | `p(easeEmphasized)` | `p(easeEmphasized)` |

### surface

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.surface.separation`<br>surface / separation | `p(string-shadow)` | `p(string-shadow)` | `p(string-shadow)` | `p(string-shadow)` |
| `theme.surface.overlayBlur`<br>surface / overlay Blur | `p(length-20)` | `p(length-20)` | `p(length-20)` | `p(length-20)` |
| `theme.surface.overlaySpread`<br>surface / overlay Spread | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |
| `theme.surface.overlayOffsetY`<br>surface / overlay Offset Y | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.surface.overlayShadowOpacity`<br>surface / overlay Shadow Opacity | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` |
| `theme.surface.scrimOpacity`<br>surface / scrim Opacity | `p(opacity-0_6)` | `p(opacity-0_6)` | `p(opacity-0_6)` | `p(opacity-0_6)` |
| `theme.surface.selectionWashOpacity`<br>surface / selection Wash Opacity | `p(opacity100)` | `p(opacity100)` | `p(opacity100)` | `p(opacity100)` |
| `theme.surface.focusWashOpacity`<br>surface / focus Wash Opacity | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` |
| `theme.surface.statusFillOpacity`<br>surface / status Fill Opacity | `p(opacity160)` | `p(opacity160)` | `p(opacity160)` | `p(opacity160)` |
| `theme.surface.pressProgressOpacity`<br>surface / press Progress Opacity | `p(opacity550)` | `p(opacity550)` | `p(opacity550)` | `p(opacity550)` |
| `theme.surface.diffFillOpacity`<br>surface / diff Fill Opacity | `p(opacity120)` | `p(opacity120)` | `p(opacity120)` | `p(opacity120)` |
| `theme.surface.gridLineOpacity`<br>surface / grid Line Opacity | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` |
| `theme.surface.veilOpacity`<br>surface / veil Opacity | `p(opacity820)` | `p(opacity820)` | `p(opacity820)` | `p(opacity820)` |
| `theme.surface.statusRowOpacity`<br>surface / status Row Opacity | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` |
| `theme.surface.statusRowSelectedOpacity`<br>surface / status Row Selected Opacity | `p(opacity320)` | `p(opacity320)` | `p(opacity320)` | `p(opacity320)` |
| `theme.surface.statusRowOpacityDark`<br>surface / status Row Opacity Dark | `p(opacity280)` | `p(opacity280)` | `p(opacity280)` | `p(opacity280)` |
| `theme.surface.statusRowSelectedOpacityDark`<br>surface / status Row Selected Opacity Dark | `p(opacity480)` | `p(opacity480)` | `p(opacity480)` | `p(opacity480)` |
| `theme.surface.frostedOpacity`<br>surface / frosted Opacity | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` |
| `theme.surface.frostedVeilOpacity`<br>surface / frosted Veil Opacity | `p(opacity120)` | `p(opacity120)` | `p(opacity120)` | `p(opacity120)` |
| `theme.surface.backdropBlurSigma`<br>surface / backdrop Blur Sigma | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.surface.dragOpacity`<br>surface / drag Opacity | `p(opacity820)` | `p(opacity820)` | `p(opacity820)` | `p(opacity820)` |
| `theme.surface.dragSourceOpacity`<br>surface / drag Source Opacity | `p(opacity350)` | `p(opacity350)` | `p(opacity350)` | `p(opacity350)` |
| `theme.surface.themePreviewDisabledOpacity`<br>surface / theme Preview Disabled Opacity | `p(opacity620)` | `p(opacity620)` | `p(opacity620)` | `p(opacity620)` |
| `theme.surface.listStatusOpacity`<br>surface / list Status Opacity | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` | `p(opacity140)` |
| `theme.surface.listStatusSelectedOpacity`<br>surface / list Status Selected Opacity | `p(opacity320)` | `p(opacity320)` | `p(opacity320)` | `p(opacity320)` |
| `theme.surface.accentSoftOpacityLight`<br>surface / accent Soft Opacity Light | `p(opacity160)` | `p(opacity160)` | `p(opacity160)` | `p(opacity160)` |
| `theme.surface.accentSoftOpacityDark`<br>surface / accent Soft Opacity Dark | `p(opacity220)` | `p(opacity220)` | `p(opacity220)` | `p(opacity220)` |
| `theme.surface.windowPaneOpacityLight`<br>surface / window Pane Opacity Light | `p(opacity-0_88)` | `p(opacity-0_88)` | `p(opacity-0_88)` | `p(opacity-0_88)` |
| `theme.surface.windowPaneOpacityDark`<br>surface / window Pane Opacity Dark | `p(opacity720)` | `p(opacity720)` | `p(opacity720)` | `p(opacity720)` |
| `theme.surface.invalidFillOpacity`<br>surface / invalid Fill Opacity | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` | `p(opacity180)` |
| `theme.surface.contactBlur`<br>surface / contact Blur | `p(length-3)` | `p(length-3)` | `p(length-3)` | `p(length-3)` |
| `theme.surface.contactOffsetY`<br>surface / contact Offset Y | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.surface.contactShadowOpacity`<br>surface / contact Shadow Opacity | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` | `p(opacity-0_13333333333333333)` |
| `theme.surface.overlayShadowColor`<br>surface / overlay Shadow Color | `p(ink1000)` | `p(ink1000)` | `p(ink1000)` | `p(ink1000)` |

### components

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.components.buttonRadius`<br>components / button Radius | `s(theme.shape.control)` | `s(theme.shape.control)` | `s(theme.shape.control)` | `s(theme.shape.control)` |
| `theme.components.buttonPaddingX`<br>components / button Padding X | `s(theme.spacing.controlPaddingX)` | `s(theme.spacing.controlPaddingX)` | `s(theme.spacing.controlPaddingX)` | `s(theme.spacing.controlPaddingX)` |
| `theme.components.buttonPaddingY`<br>components / button Padding Y | `s(theme.spacing.controlPaddingY)` | `s(theme.spacing.controlPaddingY)` | `s(theme.spacing.controlPaddingY)` | `s(theme.spacing.controlPaddingY)` |
| `theme.components.buttonHeight`<br>components / button Height | `s(theme.geometry.control.buttonHeight)` | `s(theme.geometry.control.buttonHeight)` | `s(theme.geometry.control.buttonHeight)` | `s(theme.geometry.control.buttonHeight)` |
| `theme.components.buttonBorderWidth`<br>components / button Border Width | `s(theme.shape.none)` | `s(theme.shape.none)` | `s(theme.shape.none)` | `s(theme.shape.none)` |
| `theme.components.fieldRadius`<br>components / field Radius | `s(theme.shape.control)` | `s(theme.shape.control)` | `s(theme.shape.control)` | `s(theme.shape.control)` |
| `theme.components.fieldPaddingX`<br>components / field Padding X | `s(theme.spacing.controlInset)` | `s(theme.spacing.controlInset)` | `s(theme.spacing.controlInset)` | `s(theme.spacing.controlInset)` |
| `theme.components.fieldHeight`<br>components / field Height | `s(theme.spacing.controlHeight)` | `s(theme.spacing.controlHeight)` | `s(theme.spacing.controlHeight)` | `s(theme.spacing.controlHeight)` |
| `theme.components.fieldBorderWidth`<br>components / field Border Width | `s(theme.shape.none)` | `s(theme.shape.none)` | `s(theme.shape.none)` | `s(theme.shape.none)` |
| `theme.components.menuRadius`<br>components / menu Radius | `s(theme.shape.card)` | `s(theme.shape.card)` | `s(theme.shape.card)` | `s(theme.shape.card)` |
| `theme.components.menuPadding`<br>components / menu Padding | `s(theme.spacing.overlayContentInset)` | `s(theme.spacing.overlayContentInset)` | `s(theme.spacing.overlayContentInset)` | `s(theme.spacing.overlayContentInset)` |
| `theme.components.menuItemHeight`<br>components / menu Item Height | `s(theme.geometry.layout.menuItemHeight)` | `s(theme.geometry.layout.menuItemHeight)` | `s(theme.geometry.layout.menuItemHeight)` | `s(theme.geometry.layout.menuItemHeight)` |
| `theme.components.cardRadius`<br>components / card Radius | `s(theme.shape.card)` | `s(theme.shape.card)` | `s(theme.shape.card)` | `s(theme.shape.card)` |
| `theme.components.cardPadding`<br>components / card Padding | `s(theme.spacing.containerPadding)` | `s(theme.spacing.containerPadding)` | `s(theme.spacing.containerPadding)` | `s(theme.spacing.containerPadding)` |
| `theme.components.badgeRadius`<br>components / badge Radius | `s(theme.shape.pill)` | `s(theme.shape.pill)` | `s(theme.shape.pill)` | `s(theme.shape.pill)` |
| `theme.components.badgePaddingX`<br>components / badge Padding X | `add(s(theme.spacing.tight), s(theme.spacing.space0_5))` | `add(s(theme.spacing.tight), s(theme.spacing.space0_5))` | `add(s(theme.spacing.tight), s(theme.spacing.space0_5))` | `add(s(theme.spacing.tight), s(theme.spacing.space0_5))` |

### geometry

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.geometry.control.switchTrackWidth`<br>geometry / control / switch Track Width | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.geometry.control.switchTrackHeight`<br>geometry / control / switch Track Height | `p(length-20)` | `p(length-20)` | `p(length-20)` | `p(length-20)` |
| `theme.geometry.control.switchThumb`<br>geometry / control / switch Thumb | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.geometry.control.buttonHeightXSmall`<br>geometry / control / button Height XSmall | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.geometry.control.buttonHeightSmall`<br>geometry / control / button Height Small | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.geometry.control.buttonHeight`<br>geometry / control / button Height | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.geometry.control.buttonHeightLarge`<br>geometry / control / button Height Large | `p(space1000)` | `p(space1000)` | `p(space1000)` | `p(space1000)` |
| `theme.geometry.control.buttonHeightXLarge`<br>geometry / control / button Height XLarge | `p(space1200)` | `p(space1200)` | `p(space1200)` | `p(space1200)` |
| `theme.geometry.control.pageBackgroundHitRadius`<br>geometry / control / page Background Hit Radius | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.control.presenceMarkerExtent`<br>geometry / control / presence Marker Extent | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.control.colorPickerCursorRadius`<br>geometry / control / color Picker Cursor Radius | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.control.swatchExtent`<br>geometry / control / swatch Extent | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.control.segmentedProgressHeight`<br>geometry / control / segmented Progress Height | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.control.fieldHeight`<br>geometry / control / field Height | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.geometry.control.selectionControl`<br>geometry / control / selection Control | `p(font500)` | `p(font500)` | `p(font500)` | `p(font500)` |
| `theme.geometry.control.selectionIndicatorInset`<br>geometry / control / selection Indicator Inset | `p(length-3_5)` | `p(length-3_5)` | `p(length-3_5)` | `p(length-3_5)` |
| `theme.geometry.control.selectionIcon`<br>geometry / control / selection Icon | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.geometry.control.toggleWidth`<br>geometry / control / toggle Width | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.geometry.control.toggleHeight`<br>geometry / control / toggle Height | `p(space400)` | `p(space400)` | `p(space400)` | `p(space400)` |
| `theme.geometry.control.toggleThumb`<br>geometry / control / toggle Thumb | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.geometry.control.toggleInset`<br>geometry / control / toggle Inset | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.geometry.control.segmentedDenseHeight`<br>geometry / control / segmented Dense Height | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.geometry.control.segmentedDenseInset`<br>geometry / control / segmented Dense Inset | `p(length-3)` | `p(length-3)` | `p(length-3)` | `p(length-3)` |
| `theme.geometry.control.segmentedDenseContentInset`<br>geometry / control / segmented Dense Content Inset | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |
| `theme.geometry.control.segmentedDenseItemHeight`<br>geometry / control / segmented Dense Item Height | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.geometry.control.slidingSelectionHeight`<br>geometry / control / sliding Selection Height | `p(font800)` | `p(font800)` | `p(font800)` | `p(font800)` |
| `theme.geometry.control.slidingSelectionSegmentWidth`<br>geometry / control / sliding Selection Segment Width | `p(length-41_4)` | `p(length-41_4)` | `p(length-41_4)` | `p(length-41_4)` |
| `theme.geometry.control.slidingSelectionPadding`<br>geometry / control / sliding Selection Padding | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.geometry.control.slidingSelectionIndicatorHeight`<br>geometry / control / sliding Selection Indicator Height | `p(length-30)` | `p(length-30)` | `p(length-30)` | `p(length-30)` |
| `theme.geometry.control.scrollbarThickness`<br>geometry / control / scrollbar Thickness | `p(length-5)` | `p(length-5)` | `p(length-5)` | `p(length-5)` |
| `theme.geometry.control.sliderTrackHeight`<br>geometry / control / slider Track Height | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.geometry.control.colorPlaneExtent`<br>geometry / control / color Plane Extent | `p(length-168)` | `p(length-168)` | `p(length-168)` | `p(length-168)` |
| `theme.geometry.control.textFieldIndicatorHeightFactor`<br>geometry / control / text Field Indicator Height Factor | `p(ratio-0_4)` | `p(ratio-0_4)` | `p(ratio-0_4)` | `p(ratio-0_4)` |
| `theme.geometry.control.textFieldLineHeightFactor`<br>geometry / control / text Field Line Height Factor | `p(leading300)` | `p(leading300)` | `p(leading300)` | `p(leading300)` |
| `theme.geometry.control.textFieldMinLines`<br>geometry / control / text Field Min Lines | `p(count-4)` | `p(count-4)` | `p(count-4)` | `p(count-4)` |
| `theme.geometry.control.textFieldMaxLines`<br>geometry / control / text Field Max Lines | `p(count-8)` | `p(count-8)` | `p(count-8)` | `p(count-8)` |
| `theme.geometry.control.fileExplorerRowHeightAdjustment`<br>geometry / control / file Explorer Row Height Adjustment | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |
| `theme.geometry.data.codeActionButtonSize`<br>geometry / data / code Action Button Size | `p(length-26)` | `p(length-26)` | `p(length-26)` | `p(length-26)` |
| `theme.geometry.data.codeHeaderHeight`<br>geometry / data / code Header Height | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.geometry.data.codeTerminalDot`<br>geometry / data / code Terminal Dot | `p(space100)` | `p(space100)` | `p(space100)` | `p(space100)` |
| `theme.geometry.data.codeTerminalDotGap`<br>geometry / data / code Terminal Dot Gap | `p(length-3)` | `p(length-3)` | `p(length-3)` | `p(length-3)` |
| `theme.geometry.data.codeHeaderPaddingX`<br>geometry / data / code Header Padding X | `p(space250)` | `p(space250)` | `p(space250)` | `p(space250)` |
| `theme.geometry.data.codeBodyPaddingX`<br>geometry / data / code Body Padding X | `p(space250)` | `p(space250)` | `p(space250)` | `p(space250)` |
| `theme.geometry.data.codeLineNumberWidth`<br>geometry / data / code Line Number Width | `p(space800)` | `p(space800)` | `p(space800)` | `p(space800)` |
| `theme.geometry.data.codeWrappedLineWidth`<br>geometry / data / code Wrapped Line Width | `p(length-520)` | `p(length-520)` | `p(length-520)` | `p(length-520)` |
| `theme.geometry.data.codeMaximumHeight`<br>geometry / data / code Maximum Height | `p(length-320)` | `p(length-320)` | `p(length-320)` | `p(length-320)` |
| `theme.geometry.data.codeCollapsedHeight`<br>geometry / data / code Collapsed Height | `p(length-120)` | `p(length-120)` | `p(length-120)` | `p(length-120)` |
| `theme.geometry.data.codeDisclosureSize`<br>geometry / data / code Disclosure Size | `p(length-9)` | `p(length-9)` | `p(length-9)` | `p(length-9)` |
| `theme.geometry.data.filePreviewHeight`<br>geometry / data / file Preview Height | `p(length-220)` | `p(length-220)` | `p(length-220)` | `p(length-220)` |
| `theme.geometry.data.previewCardCompactHeight`<br>geometry / data / preview Card Compact Height | `p(space1600)` | `p(space1600)` | `p(space1600)` | `p(space1600)` |
| `theme.geometry.data.previewCardStandardHeight`<br>geometry / data / preview Card Standard Height | `p(space2400)` | `p(space2400)` | `p(space2400)` | `p(space2400)` |
| `theme.geometry.data.previewCardLargeHeight`<br>geometry / data / preview Card Large Height | `p(length-192)` | `p(length-192)` | `p(length-192)` | `p(length-192)` |
| `theme.geometry.data.dateGridCellHeight`<br>geometry / data / date Grid Cell Height | `p(length-128)` | `p(length-128)` | `p(length-128)` | `p(length-128)` |
| `theme.geometry.data.keyValueLabelWidthCompact`<br>geometry / data / key Value Label Width Compact | `p(space2400)` | `p(space2400)` | `p(space2400)` | `p(space2400)` |
| `theme.geometry.data.keyValueLabelWidthStandard`<br>geometry / data / key Value Label Width Standard | `p(length-112)` | `p(length-112)` | `p(length-112)` | `p(length-112)` |
| `theme.geometry.data.stepperMarkerSize`<br>geometry / data / stepper Marker Size | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.geometry.data.stepperLabelWidth`<br>geometry / data / stepper Label Width | `p(length-60)` | `p(length-60)` | `p(length-60)` | `p(length-60)` |
| `theme.geometry.data.progressIndeterminateFraction`<br>geometry / data / progress Indeterminate Fraction | `p(ratio-0_35)` | `p(ratio-0_35)` | `p(ratio-0_35)` | `p(ratio-0_35)` |
| `theme.geometry.data.placeholderMinimumHeight`<br>geometry / data / placeholder Minimum Height | `p(length-120)` | `p(length-120)` | `p(length-120)` | `p(length-120)` |
| `theme.geometry.data.placeholderContentPaddingY`<br>geometry / data / placeholder Content Padding Y | `p(space300)` | `p(space300)` | `p(space300)` | `p(space300)` |
| `theme.geometry.data.placeholderActionPaddingY`<br>geometry / data / placeholder Action Padding Y | `p(length-5)` | `p(length-5)` | `p(length-5)` | `p(length-5)` |
| `theme.geometry.data.placeholderHatchBand`<br>geometry / data / placeholder Hatch Band | `p(length-10_5)` | `p(length-10_5)` | `p(length-10_5)` | `p(length-10_5)` |
| `theme.geometry.data.placeholderHatchGap`<br>geometry / data / placeholder Hatch Gap | `p(length-10_5)` | `p(length-10_5)` | `p(length-10_5)` | `p(length-10_5)` |
| `theme.geometry.data.placeholderLabelTracking`<br>geometry / data / placeholder Label Tracking | `p(trackingWider)` | `p(trackingWider)` | `p(trackingWider)` | `p(trackingWider)` |
| `theme.geometry.data.placeholderDetailMaximumWidth`<br>geometry / data / placeholder Detail Maximum Width | `p(length-336)` | `p(length-336)` | `p(length-336)` | `p(length-336)` |
| `theme.geometry.data.spinnerSquareFactor`<br>geometry / data / spinner Square Factor | `p(ratio-0_32)` | `p(ratio-0_32)` | `p(ratio-0_32)` | `p(ratio-0_32)` |
| `theme.geometry.data.spinnerOrbitFactor`<br>geometry / data / spinner Orbit Factor | `p(ratio-0_22)` | `p(ratio-0_22)` | `p(ratio-0_22)` | `p(ratio-0_22)` |
| `theme.geometry.data.spinnerCornerFactor`<br>geometry / data / spinner Corner Factor | `p(ratio-0_06)` | `p(ratio-0_06)` | `p(ratio-0_06)` | `p(ratio-0_06)` |
| `theme.geometry.layout.drawerWidth`<br>geometry / layout / drawer Width | `p(length-320)` | `p(length-320)` | `p(length-320)` | `p(length-320)` |
| `theme.geometry.layout.drawerHeight`<br>geometry / layout / drawer Height | `p(length-320)` | `p(length-320)` | `p(length-320)` | `p(length-320)` |
| `theme.geometry.layout.resizeHandleExtent`<br>geometry / layout / resize Handle Extent | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.overlayViewportInset`<br>geometry / layout / overlay Viewport Inset | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.railDropTargetExtent`<br>geometry / layout / rail Drop Target Extent | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.disclosureIconSize`<br>geometry / layout / disclosure Icon Size | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.treeLeadingGap`<br>geometry / layout / tree Leading Gap | `p(ratio-8)` | `p(ratio-8)` | `p(ratio-8)` | `p(ratio-8)` |
| `theme.geometry.layout.tooltipOffsetX`<br>geometry / layout / tooltip Offset X | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.primaryPaneWidth`<br>geometry / layout / primary Pane Width | `p(length-300)` | `p(length-300)` | `p(length-300)` | `p(length-300)` |
| `theme.geometry.layout.secondaryPaneWidth`<br>geometry / layout / secondary Pane Width | `p(length-350)` | `p(length-350)` | `p(length-350)` | `p(length-350)` |
| `theme.geometry.layout.primaryPaneBreakpoint`<br>geometry / layout / primary Pane Breakpoint | `p(length-400)` | `p(length-400)` | `p(length-400)` | `p(length-400)` |
| `theme.geometry.layout.primaryPaneContentBreakpoint`<br>geometry / layout / primary Pane Content Breakpoint | `p(length-800)` | `p(length-800)` | `p(length-800)` | `p(length-800)` |
| `theme.geometry.layout.responsivePaneBreakpoint`<br>geometry / layout / responsive Pane Breakpoint | `p(length-960)` | `p(length-960)` | `p(length-960)` | `p(length-960)` |
| `theme.geometry.layout.secondaryPaneBreakpoint`<br>geometry / layout / secondary Pane Breakpoint | `p(length-1120)` | `p(length-1120)` | `p(length-1120)` | `p(length-1120)` |
| `theme.geometry.layout.menuWidth`<br>geometry / layout / menu Width | `p(length-200)` | `p(length-200)` | `p(length-200)` | `p(length-200)` |
| `theme.geometry.layout.commandMenuWidth`<br>geometry / layout / command Menu Width | `p(length-300)` | `p(length-300)` | `p(length-300)` | `p(length-300)` |
| `theme.geometry.layout.menuHeaderHeight`<br>geometry / layout / menu Header Height | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.geometry.layout.menuItemHeight`<br>geometry / layout / menu Item Height | `p(font700)` | `p(font700)` | `p(font700)` | `p(font700)` |
| `theme.geometry.layout.dialogMaximumWidth`<br>geometry / layout / dialog Maximum Width | `p(length-520)` | `p(length-520)` | `p(length-520)` | `p(length-520)` |
| `theme.geometry.layout.toastMaximumWidth`<br>geometry / layout / toast Maximum Width | `p(length-360)` | `p(length-360)` | `p(length-360)` | `p(length-360)` |
| `theme.geometry.layout.inlineNoticeBreakpoint`<br>geometry / layout / inline Notice Breakpoint | `p(length-480)` | `p(length-480)` | `p(length-480)` | `p(length-480)` |
| `theme.geometry.layout.statusBarBreakpoint`<br>geometry / layout / status Bar Breakpoint | `p(length-400)` | `p(length-400)` | `p(length-400)` | `p(length-400)` |
| `theme.geometry.layout.settingsDialogMaximumWidth`<br>geometry / layout / settings Dialog Maximum Width | `p(length-1380)` | `p(length-1380)` | `p(length-1380)` | `p(length-1380)` |
| `theme.geometry.layout.settingsDialogMaximumHeight`<br>geometry / layout / settings Dialog Maximum Height | `p(length-880)` | `p(length-880)` | `p(length-880)` | `p(length-880)` |
| `theme.geometry.layout.settingsPaneGap`<br>geometry / layout / settings Pane Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.layout.settingsNavigationWidth`<br>geometry / layout / settings Navigation Width | `p(length-300)` | `p(length-300)` | `p(length-300)` | `p(length-300)` |
| `theme.geometry.layout.settingsNavigationMinimumWidth`<br>geometry / layout / settings Navigation Minimum Width | `p(length-260)` | `p(length-260)` | `p(length-260)` | `p(length-260)` |
| `theme.geometry.layout.settingsNavigationMaximumWidth`<br>geometry / layout / settings Navigation Maximum Width | `p(length-360)` | `p(length-360)` | `p(length-360)` | `p(length-360)` |
| `theme.geometry.layout.settingsContentMaximumWidth`<br>geometry / layout / settings Content Maximum Width | `p(length-820)` | `p(length-820)` | `p(length-820)` | `p(length-820)` |
| `theme.geometry.layout.themePreviewTileWidth`<br>geometry / layout / theme Preview Tile Width | `p(length-168)` | `p(length-168)` | `p(length-168)` | `p(length-168)` |
| `theme.geometry.layout.windowHeaderHeight`<br>geometry / layout / window Header Height | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.geometry.layout.windowHeaderControlSize`<br>geometry / layout / window Header Control Size | `p(space600)` | `p(space600)` | `p(space600)` | `p(space600)` |
| `theme.geometry.layout.windowAppIconSize`<br>geometry / layout / window App Icon Size | `p(length-20)` | `p(length-20)` | `p(length-20)` | `p(length-20)` |
| `theme.geometry.layout.windowIdentityGap`<br>geometry / layout / window Identity Gap | `p(space200)` | `p(space200)` | `p(space200)` | `p(space200)` |
| `theme.geometry.optical.menuIconOffsetY`<br>geometry / optical / menu Icon Offset Y | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` |
| `theme.geometry.optical.railBadgeInset`<br>geometry / optical / rail Badge Inset | `p(space50)` | `p(space50)` | `p(space50)` | `p(space50)` |
| `theme.geometry.optical.statusIconOffsetY`<br>geometry / optical / status Icon Offset Y | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` | `p(stroke100)` |
| `theme.geometry.optical.monoBaselineOffsetY`<br>geometry / optical / mono Baseline Offset Y | `p(length-minus-1)` | `p(length-minus-1)` | `p(length-minus-1)` | `p(length-minus-1)` |
| `theme.geometry.optical.uiBaselineOffsetY`<br>geometry / optical / ui Baseline Offset Y | `p(space0)` | `p(space0)` | `p(space0)` | `p(space0)` |

### dataVisualization

| Semantic ID／語意 | light | dark | ultraDark | transparent |
|---|---|---|---|---|
| `theme.dataVisualization.series`<br>data Visualization / series | `[p(sand500), p(gold500), p(ochre500), p(terracotta500), p(clay500), p(umber500)]` | `[p(sand300), p(gold300), p(ochre300), p(terracotta300), p(clay300), p(umber300)]` | `[p(sand300), p(gold300), p(ochre300), p(terracotta300), p(clay300), p(umber300)]` | `[p(sand300), p(gold300), p(ochre300), p(terracotta300), p(clay300), p(umber300)]` |
| `theme.dataVisualization.seriesWash`<br>data Visualization / series Wash | `[p(sand50), p(gold50), p(ochre50), p(terracotta50), p(clay50), p(umber50)]` | `[p(sand800), p(gold800), p(ochre800), p(terracotta800), p(clay800), p(umber800)]` | `[p(sand900), p(gold900), p(ochre900), p(terracotta900), p(clay900), p(umber900)]` | `[p(sand800), p(gold800), p(ochre800), p(terracotta800), p(clay800), p(umber800)]` |
| `theme.dataVisualization.axis`<br>data Visualization / axis | `p(warmNeutral100)` | `p(warmNeutral700)` | `p(warmNeutral750)` | `p(warmNeutral700)` |
| `theme.dataVisualization.grid`<br>data Visualization / grid | `p(warmNeutral50)` | `p(warmNeutral800)` | `p(warmNeutral900)` | `p(warmNeutral800)` |
| `theme.dataVisualization.gridStrong`<br>data Visualization / grid Strong | `p(warmNeutral200)` | `p(warmNeutral600)` | `p(warmNeutral700)` | `p(warmNeutral600)` |
| `theme.dataVisualization.label`<br>data Visualization / label | `p(ink550)` | `p(warmNeutral300)` | `p(warmNeutral300)` | `p(warmNeutral300)` |
| `theme.dataVisualization.value`<br>data Visualization / value | `p(ink900)` | `p(warmNeutral25)` | `p(warmNeutral25)` | `p(warmNeutral25)` |
| `theme.dataVisualization.plotBackground`<br>data Visualization / plot Background | `p(transparent)` | `p(transparent)` | `p(transparent)` | `p(transparent)` |
| `theme.dataVisualization.crosshair`<br>data Visualization / crosshair | `p(warmNeutral450)` | `p(warmNeutral400)` | `p(warmNeutral500)` | `p(warmNeutral400)` |
| `theme.dataVisualization.marketUp`<br>data Visualization / market Up | `p(green600)` | `p(green400)` | `p(green400)` | `p(green400)` |
| `theme.dataVisualization.marketUpWash`<br>data Visualization / market Up Wash | `p(green100)` | `p(green800)` | `p(green900)` | `p(green800)` |
| `theme.dataVisualization.marketDown`<br>data Visualization / market Down | `p(red600)` | `p(red400)` | `p(red400)` | `p(red400)` |
| `theme.dataVisualization.marketDownWash`<br>data Visualization / market Down Wash | `p(red100)` | `p(red800)` | `p(red900)` | `p(red800)` |
| `theme.dataVisualization.marketFlat`<br>data Visualization / market Flat | `p(warmNeutral450)` | `p(warmNeutral400)` | `p(warmNeutral500)` | `p(warmNeutral400)` |

## 元件、文字、表面與狀態semantic配方（118組）

不同元件有不同參數集合。「繼承」欄先提供完整基底，「設計參數」欄只覆寫變動；geometry=繼承表示所有size/padding/radius等幾何保留。狀態套用到目前size，不重新回到md。

| Semantic ID | 自然語言／別名 | 繼承 | 設計參數 |
|---|---|---|---|
| `app-background` | app background／應用背景／頁面背景 | — | background=s(theme.colors.app); foreground=s(theme.colors.text); padding=p(space0); border=none; radius=s(theme.shape.none); size=產品決定; shadow=none |
| `workspace-layout` | 工作區間距／workspace layout | — | background=繼承 app-background.background; frame-inset=s(theme.spacing.space2); frame-gap=s(theme.spacing.space2); size=產品決定; border=none |
| `surface-base` | 一般／輔助表面／surface base | — | background=s(theme.colors.surface); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-inset` | 內嵌表面／surface inset | — | background=s(theme.colors.surfaceInset); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-muted` | 弱化表面／surface muted | — | background=s(theme.colors.surfaceMuted); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-component` | 控制表面／surface component | — | background=s(theme.colors.component); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-overlay` | 浮層表面／surface overlay | — | background=s(theme.colors.overlay); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-raised` | 較亮表面／surface raised | — | background=s(theme.colors.surfaceRaised); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-stage` | 主內容表面／surface stage | — | background=s(theme.colors.stageSurface); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-accent` | 強調表面／surface accent | — | background=s(theme.colors.accent); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-accent-soft` | 柔和強調表面／surface accent-soft | — | background=s(theme.colors.accentSoft); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-transparent` | 透明表面／surface transparent | — | background=s(theme.colors.transparent); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=s(theme.components.cardRadius); size=產品決定; shadow=none; gradient=none |
| `surface-frosted` | 毛玻璃表面／frosted | surface-base | background=alpha(繼承.background,s(theme.surface.frostedOpacity)); blur-sigma=s(theme.surface.backdropBlurSigma); geometry=繼承 |
| `text-tone-primary` | 主文字色／primary text／prominent | — | color=s(theme.colors.text); typography=繼承父層; padding/border=不適用; size=內容決定 |
| `text-tone-muted` | 次要文字／說明文字／muted | text-tone-primary | color=s(theme.colors.textMuted) |
| `text-tone-faint` | 弱化文字／提示文字色／faint | text-tone-primary | color=s(theme.colors.textFaint) |
| `text-display` | 展示大字／text display | text-tone-primary | font-size=s(theme.typography.display); line-height=s(theme.typography.displayLeading); font-weight=s(theme.typography.bold); letter-spacing=s(theme.typography.displayTracking); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-h1` | 一級標題／text h1 | text-tone-primary | font-size=s(theme.typography.h1); line-height=s(theme.typography.h1Leading); font-weight=s(theme.typography.bold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-h2` | 二級標題／text h2 | text-tone-primary | font-size=s(theme.typography.h2); line-height=s(theme.typography.h2Leading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-h3` | 三級標題／text h3 | text-tone-primary | font-size=s(theme.typography.h3); line-height=s(theme.typography.h3Leading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-h4` | 四級標題／text h4 | text-tone-primary | font-size=s(theme.typography.h4); line-height=s(theme.typography.h4Leading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-lead` | 導言／text lead | text-tone-primary | font-size=s(theme.typography.lead); line-height=s(theme.typography.leadLeading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-body` | 正文／內文／text body | text-tone-primary | font-size=s(theme.typography.body); line-height=s(theme.typography.bodyLeading); font-weight=s(theme.typography.regular); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-sub` | 副正文／text sub | text-tone-primary | font-size=s(theme.typography.sub); line-height=s(theme.typography.subLeading); font-weight=s(theme.typography.regular); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-caption` | 註解小字／text caption | text-tone-primary | font-size=s(theme.typography.caption); line-height=s(theme.typography.captionLeading); font-weight=s(theme.typography.regular); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-caption-strong` | 強調小字／text captionStrong | text-tone-primary | font-size=s(theme.typography.caption); line-height=s(theme.typography.captionLeading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-mono-caption-strong` | 等寬強調小字／text monoCaptionStrong | text-tone-primary | font-size=s(theme.typography.caption); line-height=s(theme.typography.captionLeading); font-weight=s(theme.typography.bold); letter-spacing=p(space0); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-micro` | 極小字／text micro | text-tone-primary | font-size=s(theme.typography.micro); line-height=s(theme.typography.microLeading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-title` | 頁面標題／text title | text-tone-primary | font-size=s(theme.typography.title); line-height=s(theme.typography.h1Leading); font-weight=s(theme.typography.bold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-section` | 區段標題／text section | text-tone-primary | font-size=s(theme.typography.section); line-height=s(theme.typography.h3Leading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-editor` | 編輯文字／text editor | text-tone-primary | font-size=s(theme.typography.body); line-height=s(theme.typography.bodyLeading); font-weight=s(theme.typography.regular); letter-spacing=p(space0); font-family=s(theme.typography.bodyFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-terminal` | 終端文字／text terminal | text-tone-primary | font-size=s(theme.typography.body); line-height=s(theme.typography.bodyLeading); font-weight=s(theme.typography.regular); letter-spacing=s(theme.typography.labelTracking); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-body-strong` | 強調正文／text bodyStrong | text-tone-primary | font-size=s(theme.typography.body); line-height=s(theme.typography.bodyLeading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); optical-y=s(theme.geometry.optical.uiBaselineOffsetY); color=s(theme.colors.text) |
| `text-app-title` | 應用名稱／text appTitle | text-tone-primary | font-size=s(theme.typography.sub); line-height=s(theme.typography.labelLeading); font-weight=p(weight500); letter-spacing=s(theme.typography.labelTracking); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-header` | Header文字／text header | text-tone-primary | font-size=s(theme.typography.body); line-height=s(theme.typography.bodyLeading); font-weight=s(theme.typography.semiBold); letter-spacing=p(space0); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-status` | 狀態列文字／text status | text-tone-primary | font-size=s(theme.typography.sub); line-height=s(theme.typography.codeLeading); font-weight=p(weight500); letter-spacing=s(theme.typography.labelTracking); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-label` | 控制標籤／text label | text-tone-primary | font-size=s(theme.typography.sub); line-height=s(theme.typography.labelLeading); font-weight=s(theme.typography.regular); letter-spacing=s(theme.typography.labelTracking); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `text-code` | 程式碼／路徑文字／text code | text-tone-primary | font-size=s(theme.typography.sub); line-height=s(theme.typography.codeLeading); font-weight=s(theme.typography.regular); letter-spacing=s(theme.typography.labelTracking); font-family=s(theme.typography.monoFamily); fallback=s(theme.typography.monoFallback); optical-y=s(theme.geometry.optical.monoBaselineOffsetY); color=s(theme.colors.text) |
| `button-base` | 按鈕共用幾何 | — | background=s(theme.colors.component); foreground=s(theme.colors.text); padding-x=s(theme.components.buttonPaddingX); padding-y=p(space0); height=s(theme.components.buttonHeight); width=內容決定; radius=s(theme.components.buttonRadius); border-width=s(theme.components.buttonBorderWidth); border-color=s(theme.colors.border); border-style=solid（width=0 時none）; gap=s(theme.spacing.controlContentGap); typography=s(text-body); shadow=none; transition=s(theme.motion.stateTransition); curve=s(theme.motion.standard) |
| `button-primary` | 主要按鈕／主操作／button primary | button-base | background=opaque(s(theme.colors.brand)); foreground=primaryForeground(background); typography=s(text-body-strong) |
| `button-secondary` | 次要按鈕 | button-base | background=s(theme.colors.component); foreground=s(theme.colors.text); typography=s(text-body) |
| `button-ghost` | 透明按鈕／幽靈按鈕 | button-base | background=s(theme.colors.transparent); foreground=s(theme.colors.text); typography=s(text-body) |
| `button-danger` | 危險按鈕／刪除按鈕 | button-base | background=alpha(s(theme.colors.danger),s(theme.surface.statusFillOpacity)); foreground=s(theme.colors.danger); typography=s(text-body) |
| `button-dashed` | 裝飾虛線按鈕 | button-base | background=s(theme.colors.transparent); foreground=s(theme.colors.text); typography=s(text-body); decoration=dashed; dash-color=s(theme.colors.guide); dash-width=s(theme.shape.hairline); dash-length=s(theme.shape.dashedLength); dash-gap=s(theme.shape.dashedGap); dash-opacity=s(theme.shape.dashedOpacity) |
| `button-size-xs` | 按鈕 xs | button-base | height=s(theme.geometry.control.buttonHeightXSmall); padding-x=s(theme.spacing.controlInset); padding-y=p(space0); typography=s(text-caption); primary-label=xs/sm用text-caption-strong，md用text-body-strong，lg/xl用text-lead |
| `button-size-sm` | 按鈕 sm | button-base | height=s(theme.geometry.control.buttonHeightSmall); padding-x=s(theme.spacing.controlPaddingXSmall); padding-y=p(space0); typography=s(text-caption); primary-label=xs/sm用text-caption-strong，md用text-body-strong，lg/xl用text-lead |
| `button-size-md` | 按鈕 md | button-base | height=s(theme.components.buttonHeight); padding-x=s(theme.components.buttonPaddingX); padding-y=p(space0); typography=s(text-body); primary-label=xs/sm用text-caption-strong，md用text-body-strong，lg/xl用text-lead |
| `button-size-lg` | 按鈕 lg | button-base | height=s(theme.geometry.control.buttonHeightLarge); padding-x=s(theme.spacing.controlPaddingXLarge); padding-y=p(space0); typography=s(text-lead); primary-label=xs/sm用text-caption-strong，md用text-body-strong，lg/xl用text-lead |
| `button-size-xl` | 按鈕 xl | button-base | height=s(theme.geometry.control.buttonHeightXLarge); padding-x=s(theme.spacing.controlPaddingXXLarge); padding-y=p(space0); typography=s(text-lead); primary-label=xs/sm用text-caption-strong，md用text-body-strong，lg/xl用text-lead |
| `button-hover` | 按鈕 hover／focus | 繼承目前 button-* | background=over(alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)),繼承.background); primary特例=以primaryForeground(繼承.background)取代疊色text; foreground=primary時依新背景重新算，其他繼承; geometry=繼承 |
| `button-selected` | 按鈕 selected | 繼承目前 button-* | background=over(alpha(s(theme.colors.interaction),s(theme.surface.focusWashOpacity)),繼承.background); primary特例=以primaryForeground(繼承.background)取代疊色interaction; foreground=primary時依新背景重新算，其他繼承; geometry=繼承 |
| `button-disabled` | 停用按鈕 | 繼承目前 button-* | background=s(theme.colors.surfaceInset); foreground=s(theme.colors.textFaint); hover/selected=不套用; geometry=繼承 |
| `icon-button` | 獨立圖示按鈕／icon button | — | background=s(theme.colors.component); foreground=s(theme.colors.text); width=s(theme.spacing.iconButton); height=s(theme.spacing.iconButton); radius=s(theme.shape.control); padding=無額外padding，圖示置中; icon-size=s(theme.spacing.iconBase); border=none; shadow=none |
| `icon-button-inline` | 行內圖示按鈕 | icon-button | background=s(theme.colors.transparent) |
| `icon-button-window` | 視窗控制圖示按鈕 | icon-button | width=s(theme.geometry.layout.windowHeaderControlSize); height=s(theme.geometry.layout.windowHeaderControlSize) |
| `icon-button-hover` | 圖示按鈕 hover／focus | 繼承目前 icon-button* | background=over(alpha(s(theme.colors.text),byBrightness(s(theme.surface.focusWashOpacity),s(theme.surface.selectionWashOpacity))),s(theme.colors.component)); geometry/foreground=繼承 |
| `icon-button-selected` | 圖示按鈕 selected | 繼承目前 icon-button* | background=s(theme.colors.interactionSoft); foreground=s(theme.colors.text); geometry=繼承 |
| `icon-button-disabled` | 停用圖示按鈕 | 繼承目前 icon-button* | foreground=s(theme.colors.textFaint); background=selected時s(theme.colors.interactionSoft)，否則繼承rest; hover=不套用; geometry=繼承 |
| `field-base` | 輸入框／文字輸入欄位／text field | — | background=s(theme.colors.surfaceInset); foreground=s(theme.colors.text); placeholder=s(theme.colors.textFaint); icon-color=s(theme.colors.textMuted); cursor-color=s(theme.colors.interaction); height=s(theme.components.fieldHeight); width=產品決定; padding-x=s(theme.components.fieldPaddingX); padding-y=div(sub(height,mul(font-size,s(theme.geometry.control.textFieldLineHeightFactor))),p(ratio-2)); radius=s(theme.components.fieldRadius); border-width=s(theme.components.fieldBorderWidth); border-color=s(theme.colors.border); border-style=solid（width=0時none）; font-size=s(theme.typography.body); font-family=s(theme.typography.uiFamily); fallback=s(theme.typography.sansFallback); line-height=s(theme.typography.captionLeading); shadow=none |
| `field-size-xs` | 輸入框 xs | field-base | height=s(theme.spacing.controlHeightXSmall); font-size=s(theme.typography.caption); padding-x=s(theme.spacing.tight); padding-y=繼承field-base公式，以此尺寸代入 |
| `field-size-sm` | 輸入框 sm | field-base | height=s(theme.spacing.controlHeightSmall); font-size=s(theme.typography.sub); padding-x=s(theme.spacing.tight); padding-y=繼承field-base公式，以此尺寸代入 |
| `field-size-md` | 輸入框 md | field-base | height=s(theme.components.fieldHeight); font-size=s(theme.typography.body); padding-x=s(theme.components.fieldPaddingX); padding-y=繼承field-base公式，以此尺寸代入 |
| `field-size-lg` | 輸入框 lg | field-base | height=s(theme.spacing.controlHeightLarge); font-size=s(theme.typography.lead); padding-x=s(theme.spacing.base); padding-y=繼承field-base公式，以此尺寸代入 |
| `field-size-xl` | 輸入框 xl | field-base | height=s(theme.spacing.controlHeightXLarge); font-size=s(theme.typography.lead); padding-x=s(theme.spacing.comfortable); padding-y=繼承field-base公式，以此尺寸代入 |
| `field-hover` | 懸停輸入框 | field-base | background=over(alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)),s(theme.colors.surfaceInset));  geometry=繼承 |
| `field-focused` | 聚焦／選取輸入框 | field-base | background=over(alpha(s(theme.colors.interaction),s(theme.surface.focusWashOpacity)),s(theme.colors.surfaceInset));  geometry=繼承 |
| `field-error` | 錯誤輸入框 | field-base | background=alpha(s(theme.colors.danger),s(theme.surface.invalidFillOpacity));  geometry=繼承 |
| `field-disabled` | 停用輸入框 | field-base | background=s(theme.colors.surfaceMuted); foreground=s(theme.colors.textFaint); icon-color=s(theme.colors.textFaint); geometry=繼承 |
| `field-outlined` | 有邊框輸入框 | field-base | border-width=max(繼承.border-width,s(theme.shape.stroke)); border-color=focused時s(theme.colors.interaction)，否則s(theme.colors.border); geometry=繼承 |
| `field-multiline` | 多行輸入框／textarea | field-base | height=內容決定; padding-y=s(theme.spacing.controlPaddingY); min-lines=s(theme.geometry.control.textFieldMinLines); max-lines=s(theme.geometry.control.textFieldMaxLines); alignment=top-left |
| `card` | 卡片／內容卡片 | — | background=s(theme.colors.component); foreground=繼承文字角色; radius=s(theme.components.cardRadius); header-padding=s(theme.components.cardPadding); content-padding=s(theme.components.cardPadding); footer-padding=s(theme.spacing.contentInset); title=s(text-body-strong); label=s(text-label); gap=s(theme.spacing.contentInlineGap); border=none; shadow=none; size=產品決定 |
| `card-surface` | 卡片 surface | card | background=s(theme.colors.surface); shadow=none（raised只改底色） |
| `card-muted` | 卡片 muted | card | background=s(theme.colors.surfaceMuted); shadow=none（raised只改底色） |
| `card-raised` | 卡片 raised | card | background=s(theme.colors.surfaceRaised); shadow=none（raised只改底色） |
| `card-selected` | 選取卡片 | 繼承目前 card* | background=over(alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)),繼承.background); geometry=繼承 |
| `badge-base` | 狀態標記共用幾何／badge | — | padding-x=s(theme.components.badgePaddingX); padding-y=s(theme.spacing.space0_5); radius=s(theme.components.badgeRadius); typography=s(text-caption); size=內容決定; text-transform=uppercase; dot-size=s(theme.spacing.indicatorDot); dot-gap=s(theme.spacing.tight); shadow=none; tone-color=neutral時s(theme.colors.textMuted)，其他取status-* |
| `badge-neutral` | 中性標記／filled neutral | badge-base | background=s(theme.colors.component); foreground=s(theme.colors.text); border-width=s(theme.shape.hairline); border-color=s(theme.colors.divider); border-style=solid |
| `badge-status` | 語意色標記／filled status | badge-base | background=alpha(tone-color,s(theme.surface.statusFillOpacity)); foreground=s(theme.colors.text); border-width=s(theme.shape.hairline); border-color=tone-color; border-style=solid |
| `badge-outline` | 描邊標記 | badge-base | background=none; foreground=tone-color; border-width=s(theme.shape.hairline); border-color=tone-color; border-style=solid |
| `badge-solid` | 實底標記 | badge-base | background=s(theme.colors.text); foreground=s(theme.colors.stageSurface); border=none |
| `status-success` | 成功／完成 | — | color=s(theme.colors.success); on-status=s(theme.colors.onStatus); fill-opacity=s(theme.surface.statusFillOpacity); padding/border/size=繼承使用它的元件 |
| `status-warning` | 警告 | — | color=s(theme.colors.warning); on-status=s(theme.colors.onStatus); fill-opacity=s(theme.surface.statusFillOpacity); padding/border/size=繼承使用它的元件 |
| `status-danger` | 危險／錯誤／破壞性操作 | — | color=s(theme.colors.danger); on-status=s(theme.colors.onStatus); fill-opacity=s(theme.surface.statusFillOpacity); padding/border/size=繼承使用它的元件 |
| `status-info` | 資訊 | — | color=s(theme.colors.info); on-status=s(theme.colors.onStatus); fill-opacity=s(theme.surface.statusFillOpacity); padding/border/size=繼承使用它的元件 |
| `frame` | 內容Frame／app frame | — | background=s(theme.colors.surface); foreground=backgroundForeground(background); padding=p(space0); radius=s(theme.shape.panel); border=none; shadow=none; size=父布局分配; outer-gap=繼承workspace-layout.frame-gap |
| `frame-sidebar` | 側欄Frame | frame | background=s(theme.colors.surfaceInset); width=s(theme.geometry.layout.primaryPaneWidth) |
| `frame-auxiliary` | 輔助Frame | frame | background=s(theme.colors.surfaceInset) |
| `frame-right-sidebar` | 右側欄Frame | frame | background=繼承父層; radius=不適用; shadow=none; width=s(theme.geometry.layout.secondaryPaneWidth); decoration=none（bare） |
| `frame-toolbar-controls` | 工具控制區Frame | frame | background=繼承父層; radius=不適用; shadow=none; width=add(mul(s(theme.spacing.space8),p(ratio-3)),mul(s(theme.spacing.space1),p(ratio-6))); decoration=none（bare） |
| `frame-raised` | 微立體Frame | 繼承目前 frame* | shadow=s(effect-frame-relief); bare角色=不套用; geometry=繼承 |
| `panel-frame` | 面板框架／panel frame | — | background=s(theme.colors.surface); foreground=backgroundForeground(background); outer-margin=s(theme.spacing.dockMargin); padding=p(space0); radius=s(theme.shape.card); clip-radius=sub(s(theme.shape.card),s(theme.shape.stroke)); header-height=s(theme.spacing.chromeHeader); footer-height=s(theme.spacing.chromeStatusBar); border=none; shadow=none; size=父布局分配 |
| `panel-frame-stage` | 主內容面板框架 | panel-frame | background=s(theme.colors.stageSurface) |
| `panel-frame-dock` | Dock面板標題尺度 | panel-frame | header-height=s(theme.spacing.chromeTab) |
| `panel-frame-raised` | 微立體面板 | 繼承目前 panel-frame* | shadow=s(effect-frame-relief) |
| `stage-frame` | 舞台容器／stage frame | — | background=s(theme.colors.stageSurface); foreground=backgroundForeground(background); padding=p(space0); border=none; radius=不適用; shadow=none; header-min-height=s(theme.spacing.chromeHeader); status-height=s(theme.spacing.chromeStatusBar); size=父布局分配 |
| `explorer-row` | Explorer資料列／檔案列 | — | background=繼承父層; foreground=s(theme.colors.text); height=add(s(theme.spacing.controlHeightXSmall),s(theme.geometry.control.fileExplorerRowHeightAdjustment)); row-padding-end=s(theme.spacing.tight); icon-size=s(theme.spacing.iconSmall); icon-color=s(theme.colors.textMuted); icon-gap=s(theme.spacing.contentInlineGap); typography=s(text-code); leading-width=add(s(theme.spacing.iconSmall),s(theme.geometry.layout.treeLeadingGap)); indent=mul(level,s(theme.spacing.tight)); outer-padding-x=s(theme.spacing.navigationItemInset); outer-padding-y=s(theme.spacing.hairline); border=none; shadow=none; width=父布局分配 |
| `explorer-folder-row` | Explorer資料夾列 | explorer-row | height=s(theme.spacing.controlHeightXSmall); disclosure=產品選用圖示 |
| `explorer-row-hover` | Explorer懸停資料列 | explorer-row | overlay=alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)); overlay-radius=s(theme.shape.control); geometry=繼承 |
| `explorer-row-selected` | Explorer選取資料列 | explorer-row-hover | icon-color=s(theme.colors.text); overlay=繼承（hover／selected同色）；不新增虛線框 |
| `explorer-spacing-relaxed` | 較寬樹狀節奏 | explorer-row | indent=mul(level,s(theme.spacing.base)) |
| `explorer-spacing-flush` | 貼齊Explorer／flush | explorer-row | outer-padding-x=p(space0); outer-padding-y=p(space0); section-margin-x=s(theme.spacing.hairline) |
| `action-region` | 可操作資料區域 | — | background=s(theme.colors.transparent); foreground=s(theme.colors.textMuted); radius=s(theme.shape.card); padding/size=繼承所屬元件; border=none; shadow=none |
| `action-region-hover` | 可操作資料區域hover／focus | action-region | background=alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)) |
| `action-region-selected` | 可操作資料區域selected | action-region | background=s(theme.colors.interactionSoft); foreground=s(theme.colors.text) |
| `action-region-destructive` | 破壞性可操作區域 | action-region | foreground=s(theme.colors.danger); active-background=s(theme.colors.danger); active-foreground=s(theme.colors.onStatus) |
| `menu` | 彈出選單／menu panel | — | background=s(theme.colors.overlay); foreground=backgroundForeground(background); padding=s(theme.spacing.tight); radius=s(theme.components.menuRadius); width-base=s(theme.geometry.layout.menuWidth); width=依項目量測／scrollable選項，基準width-base; border=none; shadow=s(effect-menu-shadow) |
| `menu-item` | 選單項目 | action-region | radius=s(theme.shape.control); height=s(theme.components.menuItemHeight); padding-x=s(theme.components.menuPadding); padding-y=p(space0); typography=s(text-label); icon-size=s(theme.spacing.iconSmall); gap=s(theme.spacing.overlayItemGap); icon-optical-y=s(theme.geometry.optical.menuIconOffsetY) |
| `menu-item-description` | 附說明選單項目 | menu-item | height=mul(s(theme.components.menuItemHeight),p(ratio-2)); description=s(text-caption); description-color=s(theme.colors.textMuted) |
| `menu-item-selected` | 選取選單項目 | menu-item | background=s(theme.colors.interactionSoft); foreground=s(theme.colors.text) |
| `menu-item-hover` | 選單hover／keyboard focus | menu-item | background=alpha(s(theme.colors.text),s(theme.surface.selectionWashOpacity)) |
| `menu-item-danger` | 危險選單項目 | menu-item | foreground=s(theme.colors.danger); active-background=s(theme.colors.danger); active-foreground=s(theme.colors.onStatus) |
| `dialog` | 對話框 | surface-base | radius=s(theme.shape.panel); max-width=s(theme.geometry.layout.dialogMaximumWidth); heading-padding=s(theme.spacing.comfortable); content-padding=s(theme.spacing.comfortable); actions-padding=s(theme.spacing.base); heading-gap=s(theme.spacing.overlayHeadingGap); action-gap=s(theme.spacing.actionGap); title=s(text-title); label=s(text-label); primary-action=s(button-primary); secondary-action=s(button-ghost); shadow=none; positioning/scrim=產品彈出宿主決定 |
| `scrollbar` | 捲軸 | — | thumb-color=s(theme.colors.textFaint); track-color=s(theme.colors.transparent); track-border-color=s(theme.colors.transparent); thickness=s(theme.geometry.control.scrollbarThickness); radius=s(theme.shape.pill); track-visible=false; length/padding=宿主決定 |
| `tooltip` | 工具提示 | — | background=s(theme.colors.overlay); foreground=s(theme.colors.textMuted); radius=s(theme.shape.control); padding-x=s(theme.spacing.overlayContentInset); padding-y=s(theme.spacing.tight); font-family=s(theme.typography.uiFamily); font-size=s(theme.typography.caption); border=none; delay=s(theme.motion.tooltipDelay); dwell=s(theme.motion.tooltipDwell); prefer-below=false; size=內容決定 |
| `effect-paper-shadow` | 紙片雙層陰影／overlayShadow | — | contact=color alpha(s(theme.surface.overlayShadowColor),s(theme.surface.contactShadowOpacity)), offset(p(space0),s(theme.surface.contactOffsetY)), blur=s(theme.surface.contactBlur), spread=p(space0); ambient=color alpha(s(theme.surface.overlayShadowColor),s(theme.surface.overlayShadowOpacity)), offset(p(space0),s(theme.surface.overlayOffsetY)), blur=s(theme.surface.overlayBlur), spread=s(theme.surface.overlaySpread); enabled=theme.surface.separation=shadow，其餘none |
| `effect-menu-shadow` | 選單專用單層陰影 | — | color=alpha(s(theme.colors.modalScrim),s(theme.surface.overlayShadowOpacity)); offset=(p(space0),s(theme.surface.overlayOffsetY)); blur=s(theme.surface.overlayBlur); spread=s(theme.surface.overlaySpread); 不增加接觸層 |
| `effect-frame-relief` | Frame微立體陰影與亮邊 | — | scale=div(s(theme.spacing.space1),p(space100)); dark=surface.R/G/B全部小於100; shadow-rgb=s(theme.surface.overlayShadowColor); shadow-alpha=dark?p(opacity-0_47843137254901963):p(opacity-0_1803921568627451); shadow-offset=(mul(p(space50),scale),mul(p(length-3),scale)); blur=mul(p(length-5),scale); spread=mul(p(length-minus-1),scale); highlight-rgb=p(ink50); highlight-alpha=dark?p(opacity-0_07058823529411765):p(opacity-0_8509803921568627); highlight-offset=(mul(p(length-minus-1),scale),mul(p(length-minus-1),scale)); highlight-blur=p(space0); 陰影在裁切之外 |
| `motion-reduced` | 減少動態效果 | — | state-transition=p(duration0); overlay-enter=p(duration0); overlay-exit=p(duration0); 其他=繼承theme.motion |

## 查表例子

| 使用者描述 | 查表路徑 | 最終設計（範例明確選md；其他採light/rest） |
|---|---|---|
| 「做主要按鈕，尺寸用預設」 | button-base→button-primary→button-size-sm | 背景brand；padding-x12、padding-y0；height32；radius6；字體captionStrong=12/600/行高1.333；其餘繼承。 |
| 「套用專案背景」 | app-background→theme.colors.app→parchment150 | background=#E7E4DD；padding0；border none；radius0；size產品決定。 |
| 「做md主要按鈕」 | button-base→button-primary→button-size-md | 背景brand=ink900=#1D1D1D；前景parchment75=#F0EDE6；padding-x16、padding-y0；height36；width內容決定；radius6；border none；Noto Sans TC/16/600/行高1.5；gap8；shadow none。 |
| 「深色md主按鈕hover」 | 上述路徑，dark＋button-hover | resting背景白色；onPrimary=#21201B；以onPrimary alpha0.10疊在白底；前景依新背景重新算；幾何繼承。 |
| 「做輸入框」 | field-base→field-size-md | 背景#EFEDE7；文字#21201B；height40；padding-x8；padding-y=(40−16×1.3)/2=9.6；radius6；border none；Noto Sans TC/16/行高1.333。 |
| 「正文繼承容器」 | text-body＋使用者color=繼承父層 | font=Noto Sans TC/16/400/行高1.5；文字色由容器提供，不自行改成黑色。 |
| 「側欄微立體」 | frame-sidebar→frame-raised | 背景surfaceInset；width300；radius12；padding0；effect-frame-relief；框間距8由workspace-layout提供。 |
| 「選取Explorer檔案」 | explorer-row→explorer-row-selected | hover/selected同為text alpha0.10疊層；icon改主文字；label用text-code；不增加互動虛線框。 |

## 現行差異與邊界（AI不得自行修正）

| 項目 | 查證結果／規則 |
|---|---|
| button幾何 | 未指定size預設sm（32），compact預設xs（28）；renderer實際padding-y為0；theme.components.buttonPaddingY解析為8只是模型值，不能拿來覆蓋renderer。md按鈕36，並非space.controlHeight40。 |
| field幾何 | geometry.control.fieldHeight30與實際field-base高度40是不同路徑；field單行padding-y用1.3，而文字line-height用captionLeading1.333，保留此差異。 |
| 文字角色 | 全部預設prominent；tone.muted/faint改文字階層。KlpText的accent/danger/success tone目前仍解析主文字色，不能擅改成同名status色。medium實際400、extraBold700；appTitle/status角色明確500。 |
| 表面文字 | KlpSurface、AppFrame、PanelFrame、StageFrame依背景覆寫子樹文字階層；KlpCard只畫底色，不自行覆寫theme。 |
| 表面圓角 | KlpSurface非app/transparent的radius下限為shape.control；transparent表面可精確保留radius。 |
| Frame | AppFrame12；PanelFrame7、裁切5、外margin4；StageFrame本身不增加圓角。flat無微立體；raised必須由元件明確啟用。 |
| menu陰影 | KlpMenu目前是modalScrim RGB、overlayShadowOpacity的單層陰影；不是overlayShadow的雙層配方。 |
| 狀態 | 不把所有元件的hover/selected強制合併；Explorer同色，其餘依上述現存resolver。disabled優先序與outlined規則分別處理。 |
| brand/accent | buildKlpTheme的accent參數只改interaction/interactionSoft，brand不跟著改。主要按鈕依brand；預設brand繼承accent。 |
| 透明主題 | transparent為dark加視窗透明；app透明，surface/stageSurface alpha0.72，JSON的8-bit表示184/255。真正視窗透底需平台宿主。 |
| 圖示／字型 | 保留資產與授權，Flaticon Rounded thin/regular或既有Lucide。圖示清冊不是數值token。 |
| 未列元件 | 本檔完整列出350個theme欄位與已查證配方；未列的複合Widget不是已定型模板，不得聲稱有同名recipe。產品可依既有surface/text/spacing等語意組合。 |
| 架構 | 不重建declarative runtime、不引用lib/src、不使用私有八槽schema作為consumer入口。 |
| 來源 | primitive_token／klp_palette／default_*／各ThemeExtension與klp_geometry_theme；button_style、text_field_style/frame、KlpSurface、Card/BadgeFrame、MenuMetrics/MenuState、AppFrame/PanelFrame/StageFrame、ExplorerRow、klp_text。 |
| 驗證 | 已檢查全部primitive/semantic引用、配方繼承無循環、350個theme欄位覆蓋；本次僅整理文件，未改元件或進行Flutter編譯／視覺驗收。 |

